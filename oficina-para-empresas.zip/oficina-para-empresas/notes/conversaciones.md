# Reglas de comunicación

Usa el idioma del destinatario. Distingue hechos, hipótesis y datos por confirmar. No contactes a terceros ni realices compromisos.
