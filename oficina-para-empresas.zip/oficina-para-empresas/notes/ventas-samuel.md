# Guía comercial (plantilla)

Investiga antes de recomendar. Explica el alcance, dependencias, costos por confirmar y siguiente paso. No inventes resultados.
