# Conocimiento interno

Añade aquí procedimientos y documentación aprobada por la empresa. Evita credenciales y datos personales.
