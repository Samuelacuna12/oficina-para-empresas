# Contexto de la empresa

Completa este archivo con productos, servicios, clientes, tono, límites y condiciones comerciales. No inventes datos que no estén aquí o en la tarea.
