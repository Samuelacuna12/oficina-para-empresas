import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';

const root=path.dirname(fileURLToPath(import.meta.url));
const config=JSON.parse(fs.readFileSync(path.join(root,'data/config.json'),'utf8'));
const url=`http://127.0.0.1:${config.port}`;
function status(){return new Promise(resolve=>{
  const req=http.get(url+'/api/state',res=>{
    let data='';res.on('data',d=>data+=d);res.on('end',()=>{
      try{const s=JSON.parse(data);resolve(res.statusCode===200&&s.name===config.name?'ready':'occupied');}
      catch{resolve('occupied');}
    });
  });
  req.setTimeout(1000,()=>req.destroy());req.on('error',e=>resolve(e.code==='ECONNREFUSED'?'closed':'occupied'));
});}
let current=await status();
if(current==='occupied')throw new Error('Hay otro servicio usando la dirección de la oficina. No se cerró ni modificó.');
if(current==='closed'){
  const runtime=path.join(root,'runtime');fs.mkdirSync(runtime,{recursive:true});
  const log=fs.openSync(path.join(runtime,'server.log'),'a');
  const child=spawn(process.execPath,[path.join(root,'server.mjs')],{cwd:root,detached:true,stdio:['ignore',log,log]});
  child.on('error',e=>console.error('No se pudo abrir la oficina: '+e.message));
  child.unref();fs.closeSync(log);
  fs.writeFileSync(path.join(runtime,'server.pid'),String(child.pid));
  for(let n=0;n<30;n++){
    await new Promise(r=>setTimeout(r,100));current=await status();if(current==='ready')break;
  }
}
if(current!=='ready')throw new Error('La oficina no respondió. Revisa runtime/server.log.');
console.log('Oficina lista: '+url);
