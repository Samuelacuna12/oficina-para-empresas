'use strict';
import {OfficeWorld} from './office-world.js';
import {Pipeline} from './pipeline.js';
import {OfficeGadgets} from './office-gadgets.js';
let pipeline=null;
let world=null,gadgets=null,worldFailed=false;
const $=id=>document.getElementById(id);
const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let state=null,selectedAgent='director',selectedTask=null,lastState='',busy=false;
const statusNames={pending:'Pendiente',queued:'En cola',running:'Trabajando',done:'Entregado',error:'Requiere atención',interrupted:'Interrumpido',cancelled:'Cancelado'};
const icons={pending:'○',queued:'◷',running:'◉',done:'✓',error:'!',interrupted:'!',cancelled:'−'};
const titles={tablero:['Pipeline de trabajo.','Asigna el trabajo, sigue su avance y recibe cada entrega en su tarjeta.'],oficina:['Un equipo. Tu dirección.','Dale una tarea a un agente. Revisa el trabajo cuando esté listo.'],prospectos:['Módulos de tu empresa.','Personaliza el trabajo con el cuestionario de optimización.'],resultados:['El trabajo queda aquí.','Resultados, decisiones y próximos pasos de tu equipo.'],conexiones:['Integraciones propias.','Configura conexiones autorizadas para tu empresa.']};
function toast(text,error=false){$('toast').textContent=text;$('toast').style.background=error?'#8b3e35':'#193e34';$('toast').hidden=false;clearTimeout(toast.timer);toast.timer=setTimeout(()=>$('toast').hidden=true,5000);}
async function api(url,data){const res=await fetch(url,{method:data?'POST':'GET',headers:data?{'Content-Type':'application/json','X-Office-Token':state?.csrf}:undefined,body:data?JSON.stringify(data):undefined});const j=await res.json();if(!res.ok)throw new Error(j.error||'No se pudo completar la acción.');return j;}
function time(ts){return new Intl.DateTimeFormat('es-CO',{timeZone:'America/Bogota',hour:'2-digit',minute:'2-digit',day:'numeric',month:'short'}).format(new Date(ts));}
function agentFor(id){return state.agents.find(a=>a.id===id)||state.agents[0];}
function draftLink(t){try{const u=new URL(t.correoDraft?.web_url);return u.origin==='https://mail.google.com'?`<a class="button primary" href="${h(u.href)}" target="_blank" rel="noopener">Abrir borrador en correo ↗</a>`:'';}catch{return '';}}
function route(){let view=location.hash.slice(1)||'oficina';if(!titles[view])view='oficina';document.querySelectorAll('.view').forEach(el=>el.hidden=el.id!=='view-'+view);document.querySelectorAll('[data-view]').forEach(el=>el.classList.toggle('active',el.dataset.view===view));$('page-title').textContent=titles[view][0];$('page-subtitle').textContent=titles[view][1];$('view-label').textContent=view==='tablero'?'Pipeline':view[0].toUpperCase()+view.slice(1);$('pilot-button').hidden=['conexiones','tablero'].includes(view);$('board-new').hidden=view!=='tablero';document.body.dataset.view=view;if(view!=='oficina'){document.body.classList.remove('office-expanded');$('world-immersive').textContent='Ampliar oficina ⤢';$('world-immersive').setAttribute('aria-pressed','false');}if(state&&view==='resultados')renderResult();}
function chooseAgent(id,focus=false){selectedAgent=id;$('agent-select').value=id;const a=agentFor(id);$('agent-avatar').textContent=a.short;$('agent-job').textContent=a.job;renderScene();if(focus)$('task-text').focus();}
function roomStatus(a){const running=state.tasks.find(t=>t.agent===a.id&&t.status==='running');const queued=state.tasks.filter(t=>t.agent===a.id&&t.status==='queued').length;const latest=state.tasks.find(t=>t.agent===a.id);return running?{name:'Trabajando',type:'working',color:'#21896e'}:queued?{name:`${queued} en cola`,type:'idle',color:'#8a9ea4'}:latest&&['error','interrupted'].includes(latest.status)?{name:'Revisar tarea',type:'attention',color:'#b78a3b'}:{name:'Disponible',type:'idle',color:'#a7b6bb'};}
function renderScene(){
  if(!state||worldFailed)return;
  if(!world){try{world=new OfficeWorld($('scene'),{
    agents:state.agents,
    onSelect:id=>chooseAgent(id),
    onAssign:id=>pipeline.create(id),
    onResult:id=>pipeline.open(id),
    onReview:()=>pipeline.jump('review'),
    onNotice:message=>toast(message),
    onGadget:(tool,context)=>gadgets?.open(tool,context),
    onContext:context=>gadgets?.setContext(context)
  });
  gadgets=new OfficeGadgets({world:()=>world,onAssign:id=>pipeline.create(id),onResult:id=>pipeline.open(id),onReview:()=>pipeline.jump('review'),onNotice:toast,board:dept=>{$('board-clear').click();$('board-department').value=state.departments.some(d=>d.id===dept)?dept:'';pipeline.render();location.hash='tablero';}});
  world.setPaused(world.paused);}catch(e){worldFailed=true;console.error(e);return;}}
  world.update(state,selectedAgent);
  gadgets?.update(state);
}
function taskRow(t){const a=agentFor(t.agent);return `<button class="task-row ${selectedTask===t.id?'selected':''}" data-task="${t.id}"><span class="state-marker ${t.status}">${icons[t.status]||'·'}</span><span><span class="task-title">${h(t.title)}</span><span class="task-meta">${h(a.name)} · ${statusNames[t.status]||h(t.status)}</span></span></button>`;}
function renderTasks(){const completed=state.tasks.filter(t=>t.status==='done').length;$('metric-running').textContent=state.tasks.filter(t=>t.status==='running').length;$('metric-done').textContent=completed;$('result-count').textContent=completed;$('tasks-total').textContent=state.tasks.length+' tareas';$('recent-tasks').innerHTML=state.tasks.length?state.tasks.slice(0,3).map(taskRow).join(''):'<div class="empty"><strong>El equipo está listo.</strong>Asigna una tarea o inicia el piloto para ver el trabajo aquí.</div>';$('all-tasks').innerHTML=state.tasks.length?state.tasks.map(taskRow).join(''):'<div class="empty">Todavía no hay tareas.<br>Empieza desde la oficina.</div>';if(!selectedTask&&state.tasks.length)selectedTask=state.tasks.find(t=>t.status==='running')?.id||state.tasks[0].id;renderResult();}
function renderResult(){if(!state)return;const t=state.tasks.find(t=>t.id===selectedTask);if(!t){$('result-detail').innerHTML='<div class="empty"><strong>Tu próximo resultado aparecerá aquí.</strong>Selecciona una tarea para revisar su contenido.</div>';return;}
  const a=agentFor(t.agent);$('result-detail').innerHTML=`<p class="eyebrow">${h(a.name)} / ${h(a.person)}</p><h2>${h(t.title)}</h2><div class="result-meta"><span class="badge ${['error','interrupted'].includes(t.status)?'error':''}">${statusNames[t.status]}</span><span>${time(t.createdAt)}</span></div>${t.result?`<div class="result-actions"><button class="button primary" data-open-task="${t.id}">Abrir tarjeta</button>${draftLink(t)}<button class="button secondary" data-copy-result="${t.id}">Copiar resultado</button><a class="button secondary" href="/result/${t.id}">Descargar</a></div><div class="result-text">${h(t.result)}</div>`:t.error?`<div class="task-error">${h(t.error)}</div><div class="result-actions"><button class="button secondary" data-retry="${t.id}">Volver a intentar</button></div>`:`<div class="result-wait">${h(t.activity)}${t.status==='running'?'<br>El agente está ejecutando esta tarea con Codex.':''}</div>${['running','queued'].includes(t.status)?`<div class="result-actions"><button class="button secondary" data-cancel="${t.id}">Detener tarea</button></div>`:''}`}<p class="subtle" style="margin-top:20px">Solicitud: ${h(t.text)}</p>`;
}
function renderProspects(){
 const q=$('prospect-search').value.trim().toLowerCase();
 const list=state.prospects.filter(p=>(p.empresa+' '+p.ciudad+' '+p.sector+' '+(p.country||'')).toLowerCase().includes(q));
 const link=(url,label)=>{try{const u=new URL(url);return /^https?:$/.test(u.protocol)?`<a href="${h(u.href)}" target="_blank" rel="noopener">${h(label)} ↗</a>`:'';}catch{return '';}};
 const chat=p=>{
  if(p.chatUrl)return link(p.chatUrl,/instagram\.com/.test(p.chatUrl)?'Abrir perfil de Instagram':/wa\.me|whatsapp\.com/.test(p.chatUrl)?'Abrir WhatsApp':'Abrir contacto oficial');
  const wa=p.businessContact?.find(x=>/whatsapp/i.test(x.type));
  if(wa){let digits=wa.value.replace(/\D/g,'');const dial={'Colombia':['57',10],'México':['52',10],'Estados Unidos':['1',10],'España':['34',9],'Costa Rica':['506',8],'Guatemala':['502',8]}[p.country];if(dial&&digits.length===dial[1])digits=dial[0]+digits;if(digits.length>=10&&digits.length<=15)return link('https://wa.me/'+digits,'Abrir WhatsApp')+'<small>Canal comercial publicado</small>';}
  const instagram=typeof p.instagram==='string'?p.instagram:p.instagramUrl;
  return link(instagram||p.publicContactPage||p.fuente,instagram?'Abrir Instagram':'Abrir contacto oficial');
 };
 $('module-nav-count').textContent=state.prospects.length;
 $('metric-prospects').textContent=state.prospects.length;
 $('metric-selected').textContent=state.prospects.filter(p=>p.developmentDecision==='Desarrollar').length+' seleccionados para desarrollar';
 $('coordination-plan').innerHTML=`<div class="coordination-targets"><span><b>50</b> Google / día</span><span><b>50</b> Instagram / día</span><span><b>Gratis</b> LinkedIn</span></div><p class="subtle">Adapta el espacio al tamaño y procesos de tu empresa.</p>${link(state.research?.sheetUrl,'Abrir Google Sheets y marcar decisiones')}`;
 $('prospect-rows').innerHTML=list.map(p=>`<tr><td><strong>${h(p.empresa)}</strong><small>${h(p.ciudad)} · ${h(p.country||'')} · ${h(p.sector)}</small>${link(p.fuente,'Web oficial')}</td><td>${h(p.oferta)}<small>${h(p.automationHypothesis||'')}</small></td><td>${p.monthlySales!==null&&p.monthlySales!==undefined?h(p.monthlySales):'Por confirmar'}<small>No se estima por seguidores</small></td><td><span class="badge">${h(p.status)}</span><small>${h(p.developmentDecision||'Pendiente')}</small></td><td>${chat(p)}</td></tr>`).join('');
}
function renderConnection(){const c=state.connection;$('connection-status').innerHTML=c.verified&&c.email===state.email?`<div class="verified-line"><span class="dot"></span>Cuenta verificada · ${h(c.label)}</div><p class="verified-date">Última comprobación: ${time(c.verifiedAt)}</p>`:'<p class="task-error">Falta verificar esta conexión.</p>';}
async function refresh(){try{const s=await api('/api/state');state=s;gadgets?.setConnected(true);world?.setScreensConnected?.(true);$('server-state').textContent='Oficina conectada';$('server-dot').style.background='#21896e';const fingerprint=JSON.stringify(s);if(fingerprint!==lastState){lastState=fingerprint;pipeline?.update(s);if(!$('agent-select').options.length)$('agent-select').innerHTML=pipeline.options(selectedAgent);chooseAgent(selectedAgent);renderTasks();renderProspects();renderConnection();}}catch(e){console.error(e);gadgets?.setConnected(false);world?.setScreensConnected?.(false);$('server-state').textContent='Oficina sin conexión';$('server-dot').style.background='#bd6953';}}
$('task-form').addEventListener('submit',async e=>{e.preventDefault();const button=e.submitter;button.disabled=true;try{const t=await api('/api/tasks',{agent:selectedAgent,text:$('task-text').value});selectedTask=t.id;$('task-text').value='';await refresh();pipeline.open(t.id);toast('Tarea asignada. Recibirás la entrega en esta tarjeta.');}catch(e){toast(e.message,true);}finally{button.disabled=false;}});
$('agent-select').addEventListener('change',e=>chooseAgent(e.target.value));
$('owner-review').onclick=()=>pipeline.jump('review');
$('owner-assign').onclick=()=>pipeline.create('director');
document.querySelectorAll('[data-pan]').forEach(b=>b.onclick=()=>world?.panView(...({up:[0,1],left:[-1,0],down:[0,-1],right:[1,0]}[b.dataset.pan])));
document.addEventListener('keydown',e=>{if(!e.defaultPrevented&&!$('view-oficina').hidden&&!e.target.closest('input,textarea,select,dialog,[contenteditable]')&&!document.querySelector('dialog[open]'))world?.handleNavigationKey(e);});
$('world-immersive').onclick=()=>{const expanded=document.body.classList.toggle('office-expanded');$('world-immersive').textContent=expanded?'Salir de vista amplia ⤡':'Ampliar oficina ⤢';$('world-immersive').setAttribute('aria-pressed',String(expanded));};
$('world-gather').addEventListener('click',()=>world?.gather());
$('world-home').addEventListener('click',()=>world?.home());
$('world-pause').addEventListener('click',()=>world?.setPaused(!world.paused));
$('world-reset').addEventListener('click',()=>world?.cameraHome());
$('world-zoom-in').addEventListener('click',()=>world?.zoomBy(.15));
$('world-zoom-out').addEventListener('click',()=>world?.zoomBy(-.15));
$('pilot-button').addEventListener('click',()=>{location.href='/onboarding.html';});
$('verify-mail').addEventListener('click',()=>{location.href='/onboarding.html';});
$('prospect-search').addEventListener('input',renderProspects);
$('show-offers').addEventListener('click',()=>$('offers-dialog').showModal());
document.querySelectorAll('.close-dialog').forEach(b=>b.addEventListener('click',()=>b.closest('dialog').close()));
document.addEventListener('click',async e=>{
  const open=e.target.closest('[data-open-task]');if(open){pipeline.open(open.dataset.openTask);return;}
  const task=e.target.closest('[data-task]');if(task){selectedTask=task.dataset.task;if(location.hash==='#resultados')renderTasks();else pipeline.open(selectedTask);return;}
  const prospect=e.target.closest('[data-prospect]');if(prospect){const p=state.prospects.find(p=>p.id===prospect.dataset.prospect);if(!p.email){location.hash='oficina';chooseAgent('messages');$('task-text').value='Prepara un primer contacto para '+p.empresa+'. Usa únicamente los hechos investigados y no inventes un email.';return;}$('draft-company').textContent=p.empresa;$('draft-to').value=p.email;$('draft-subject').value='Una idea para el proceso comercial de '+p.empresa;$('draft-body').value=p.message+'\n\nPuedes ver el alcance de mi trabajo aquí:\n'+p.landing+'\n\nTu empresa';$('draft-dialog').showModal();return;}
  const copy=e.target.closest('[data-copy-result]');if(copy){try{await navigator.clipboard.writeText(state.tasks.find(t=>t.id===copy.dataset.copyResult).result);toast('Resultado copiado.');}catch{toast('El navegador no permitió copiar. Selecciona el texto del resultado.',true);}return;}
  const cancel=e.target.closest('[data-cancel]');if(cancel){try{await api('/api/cancel/'+cancel.dataset.cancel,{});await refresh();}catch(e){toast(e.message,true);}return;}
  const retry=e.target.closest('[data-retry]');if(retry){await pipeline.action(retry.dataset.retry,'start');}
});
$('draft-form').addEventListener('submit',e=>{e.preventDefault();toast('La plantilla no se conecta a correo. Copia el texto y conéctalo desde tus herramientas autorizadas.',true);});
$('draft-copy').addEventListener('click',async()=>{try{await navigator.clipboard.writeText($('draft-body').value);toast('Mensaje copiado.');}catch{toast('Selecciona el texto para copiarlo.',true);}});
pipeline=new Pipeline({api,refresh,toast,time});
window.addEventListener('hashchange',route);
function clock(){$('clock').textContent=new Intl.DateTimeFormat('es-CO',{timeZone:'America/Bogota',hour:'2-digit',minute:'2-digit'}).format(new Date())+' · Bogotá';}clock();setInterval(clock,30000);route();refresh();setInterval(refresh,2200);
