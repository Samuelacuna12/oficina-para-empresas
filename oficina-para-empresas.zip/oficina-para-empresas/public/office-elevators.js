import * as THREE from './vendor/three.module.js';
import {ElevatorController,ELEVATORS,ELEVATOR_FLOORS,ELEVATOR_SIZE} from './elevator-state.js';

/** Two visible, independent cars. Existing office materials are the reference lock.
 * Motion is functional continuity: 240ms doors, eased physical travel; no idle loop.
 * Pass the same helpers as buildArchitecture; no DOM or global event listeners here.
 * Advance update(dt) even in reduced-motion mode (it then completes discrete rides).
 * riderPosition(id) is world space: copy to root.position, without reparenting figures.
 */
export function buildElevators(scene,{box,solid,group,labelTexture},{reducedMotion=false}={}){
  const controller=new ElevatorController({reducedMotion}),root=group(scene),cars=new Map(),portals=[],ownMaterials=[],shaftParts=[];
  let visibleFloor=null;
  const shaftHeight=ELEVATOR_FLOORS.at(-1)+3;
  root.name='Twin elevators';
  const material=options=>{const m=new THREE.MeshStandardMaterial(options);ownMaterials.push(m);return m;};
  const dark=material({color:'#263b3b',roughness:.35,metalness:.65});
  const wood=material({color:'#ad7950',roughness:.6});
  const stone=material({color:'#d4c6ae',roughness:.68});
  const glass=material({color:'#a2c6ca',transparent:true,opacity:.19,roughness:.12,metalness:.08,depthWrite:false});
  const doorGlass=material({color:'#9fc7ca',transparent:true,opacity:.38,roughness:.15,metalness:.2,depthWrite:false});
  const light=material({color:'#ffe2a8',emissive:'#ffe2a8',emissiveIntensity:.65,roughness:.3});
  function doors(parent,z){
    const leaves=[];
    // Four telescopic leaves stack inside the narrow side pockets: no overlap
    // with the neighbouring car, and a >1m opening for the .9m block figures.
    for(const sign of[-1,1])for(let n=0;n<2;n++){
      const leaf=group(parent,sign*(.14+n*.28),0,z+n*.025);
      box(leaf,0,1.21,0,.28,2.42,.035,doorGlass);
      for(const x of[-.132,.132])box(leaf,x,1.21,.025,.014,2.42,.018,dark);
      for(const y of[.025,2.4])box(leaf,0,y,.025,.28,.025,.018,dark);
      leaves.push({node:leaf,closedX:leaf.position.x,openX:sign*.675});
    }
    return leaves;
  }
  for(const spec of ELEVATORS){
    const shaft=group(root,spec.x,0,spec.z);shaft.name=`Elevator ${spec.name} shaft`;
    // Open cutaway front, clear sides and exposed guide rails show real travel.
    for(const x of[-.79,.79]){
      box(shaft,x,shaftHeight/2,-.02,.045,shaftHeight,.045,dark);
      box(shaft,x,shaftHeight/2,-.73,.035,shaftHeight,.035,dark);
      box(shaft,x,shaftHeight/2,-.35,.018,shaftHeight,.75,glass);
    }
    box(shaft,0,shaftHeight/2,-.8,1.55,shaftHeight,.025,glass);
    shaftParts.push(...shaft.children);
    const cabin=group(shaft,0,spec.initialY,0);cabin.name=`Elevator ${spec.name} cabin`;
    box(cabin,0,-.065,0,ELEVATOR_SIZE.width,.13,ELEVATOR_SIZE.depth,dark);
    box(cabin,0,.012,0,1.39,.025,1.38,wood);
    box(cabin,0,2.74,0,1.5,.12,1.5,dark);
    box(cabin,0,2.67,0,1.18,.025,1.15,light);
    box(cabin,0,1.31,-.735,1.5,2.62,.045,glass);
    for(const x of[-.72,.72])box(cabin,x,1.31,0,.035,2.62,1.45,glass);
    for(const x of[-.73,.73])for(const z of[-.73,.73])box(cabin,x,1.33,z,.035,2.66,.035,dark);
    box(cabin,0,.98,-.67,1.24,.045,.045,wood);
    const leaves=doors(cabin,.76);
    cars.set(spec.id,{cabin,leaves});
    for(const y of ELEVATOR_FLOORS){
      const landing=group(shaft,0,y,0);landing.name=`Elevator ${spec.name} floor ${y/6+1}`;
      for(const x of[-.815,.815])box(landing,x,1.42,.85,.065,2.84,.12,stone);
      box(landing,0,2.85,.85,1.7,.16,.12,stone);
      box(landing,0,.025,.85,1.55,.05,.28,dark);
      const gate=doors(landing,.84);
      const indicator=material({color:'#6c8b80',emissive:'#20765d',emissiveIntensity:.18});
      box(landing,.69,2.67,.94,.12,.045,.025,indicator);
      if(labelTexture){const m=labelTexture(`${spec.name}  ·  ${y/6+1}`,'#263b3b','#f0ede5');ownMaterials.push(m);solid(landing,new THREE.PlaneGeometry(.8,.25),m,0,2.67,.925);}
      portals.push({id:spec.id,y,leaves:gate,indicator,group:landing});
    }
  }
  function apply(){
    const state=controller.getState();
    const height=visibleFloor===null?shaftHeight:Math.min(shaftHeight,visibleFloor+3.3);
    for(const p of shaftParts){p.position.y=height/2;p.scale.y=height;}
    const slide=(leaves,amount)=>leaves.forEach(l=>{l.node.position.x=l.closedX+(l.openX-l.closedX)*amount;});
    for(const s of state){const c=cars.get(s.id);c.cabin.position.y=s.y;c.cabin.visible=visibleFloor===null||s.y<=visibleFloor+.1;slide(c.leaves,s.door);
      for(const p of portals.filter(p=>p.id===s.id)){p.group.visible=visibleFloor===null||p.y<=visibleFloor;const here=Math.abs(s.y-p.y)<.001;slide(p.leaves,here?s.door:0);p.indicator.emissiveIntensity=here?.75:.08;p.indicator.color.set(here?'#73c5a3':'#6c8b80');}
    }
  }
  root.traverse(o=>{if(o.isMesh&&o.material?.transparent)o.castShadow=false;});apply();
  return{
    root,cars,controller,
    requestRide:options=>controller.requestRide(options),
    getRide:id=>controller.getRide(id),
    riderPosition:id=>controller.riderPosition(id),
    cancelRide:id=>controller.cancelRide(id),
    getState:()=>controller.getState(),
    drainEvents:()=>controller.drainEvents(),
    setReducedMotion:value=>controller.setReducedMotion(value),
    setVisibleFloor(y){visibleFloor=ELEVATOR_FLOORS.includes(y)?y:null;apply();},
    update(dt){const state=controller.update(dt);apply();return state;},
    dispose(){root.removeFromParent();for(const m of ownMaterials){m.map?.dispose();m.dispose();}root.traverse(o=>{if(o.geometry?.type==='PlaneGeometry')o.geometry.dispose();});}
  };
}
