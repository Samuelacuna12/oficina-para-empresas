import {ELEVATORS,ELEVATOR_FLOORS,ELEVATOR_SIZE} from './elevator-state.js';
// Reference lock: preserve the current wood/stone/glass dollhouse; compact occupied
// wings into four work floors plus management suite. Coordination is a workstation,
// not another room. Order stays aligned with the example team.
// Floor coordinates shared by the building, characters and navigation.
export const WINGS=[
 {id:'marketing',name:'Marketing',color:'#ca6a51',x:-10,y:0,z:0,count:5},
 {id:'sales',name:'Ventas',color:'#4384ad',x:10,y:0,z:0,count:5},
 {id:'innovation',name:'Innovación',color:'#8371b2',x:-10,y:6,z:0,count:3},
 {id:'finance',name:'Finanzas',color:'#398b76',x:10,y:6,z:0,count:4},
 {id:'intelligence',name:'Inteligencia',color:'#b48a39',x:-10,y:12,z:0,count:4},
 {id:'operations-wing',name:'Operaciones',color:'#23827c',x:10,y:12,z:0,count:7},
 {id:'product-wing',name:'Producto',color:'#bb5b65',x:-10,y:18,z:0,count:7},
 {id:'customer-success-wing',name:'Servicio al cliente',color:'#2b73a2',x:10,y:18,z:0,count:7},
 {id:'coordination',name:'Coordinación',color:'#17685e',x:-5,y:18,z:2.7,count:1,compact:true,host:'product-wing'}
];
export const MANAGEMENT={id:'management',name:'Gerencia · Penthouse',color:'#20594b',x:10,y:24,z:0,count:1};
export const CHIEF_IDS=['marketing-head','director','innovation-head','finance-head','intelligence-head','operations-wing-head'];
export const SEATS=WINGS.flatMap(d=>{
 const offsets=d.count===7?[[-5,-3.7],[0,-3.7],[5,-3.7],[-5,-.5],[0,-.5],[5,-.5],[0,2.7]]:d.compact?[[0,d.z]]:d.count===5?[[-5,-2.5],[0,-2.5],[5,-2.5],[-3,1.5],[3,1.5]]:d.count===4?[[-4,-2.5],[4,-2.5],[-4,1.5],[4,1.5]]:[[-5,-2.5],[0,-2.5],[5,-2.5]];
 return offsets.map(([x,z])=>({x:d.x+x,y:d.y,z,department:d.id,toward:1,facing:Math.PI}));
});
export const DESKS=SEATS.map(s=>[s.x,s.z,s.y]);
export const HOMES=SEATS.map(s=>({x:s.x,y:s.y,z:s.z+1.35,facing:Math.PI}));
export const MANAGER_HOME={x:10,y:MANAGEMENT.y,z:-3.8,facing:0};
export const EXEC_MEETING=CHIEF_IDS.map((_,i)=>({x:14+Math.sin(i/CHIEF_IDS.length*Math.PI*2)*1.85,y:MANAGEMENT.y,z:2.5+Math.cos(i/CHIEF_IDS.length*Math.PI*2)*1.85}));
export const MANAGER_MEETING=Object.freeze({x:14,y:MANAGEMENT.y,z:5.2,facing:Math.PI});
export const EXECUTIVE_ENTRY=Object.freeze({x:14,y:MANAGEMENT.y,z:6.25});
const insideExecutive=(x,z)=>x>11.14&&x<=18.3&&z>-.11&&z<5.95;
export const COMMON_ROOMS=Object.freeze({
 canteen:Object.freeze({id:'canteen',name:'Comedor',x:-29,y:0,z:0,width:14,depth:13}),
 disco:Object.freeze({id:'disco',name:'Discoteca · After Hours · Piso 5',x:-10,y:24,z:.5,width:16.8,depth:12.5}),
 assembly:Object.freeze({id:'assembly',name:'Sala de todos',x:29,y:0,z:0,width:14,depth:13})
});
export const DISCO_SPOTS=Object.freeze(Array.from({length:HOMES.length},(_,i)=>Object.freeze(i<42?{x:-15.7+(i%7)*1.9,y:24,z:-2.9+Math.floor(i/7)*1.44,facing:(i%3-1)*.35}:{x:-10,y:24,z:-5.6,facing:0})));
export const DISCO_MANAGER_SPOT=Object.freeze({x:-10,y:24,z:5.9,facing:Math.PI});
export const ASSEMBLY_TABLE=Object.freeze({x:29,y:0,z:0,width:8,depth:2.8});
export const CANTEEN_TABLES=Object.freeze([-3.8,0,3.8].flatMap(z=>[-32.2,-25.8].map(x=>Object.freeze({x,y:0,z,width:2.6,depth:1.4}))));
export const ASSEMBLY_SEATS=Object.freeze([
 ...[-1,1].flatMap(side=>Array.from({length:10},(_,i)=>({x:24.5+i,y:0,z:side*2.35,facing:side>0?Math.PI:0}))),
 {x:23.9,y:0,z:0,facing:Math.PI/2},{x:34.1,y:0,z:0,facing:-Math.PI/2},
 ...[-1,1].flatMap(side=>Array.from({length:11},(_,i)=>({x:24+i,y:0,z:side*4.7,facing:side>0?Math.PI:0})))
]);
export const CANTEEN_SEATS=Object.freeze([...CANTEEN_TABLES.flatMap((table,i)=>
 [-1,1].flatMap(side=>[-.72,.72].map(dx=>({x:table.x+dx,y:0,z:table.z+side*1.38,facing:side>0?Math.PI:0}))).slice(0,i<4?4:3)
),...[-35.2,-22.8].flatMap((x,side)=>Array.from({length:8},(_,i)=>({x,y:0,z:-5.25+i*1.5,facing:side? -Math.PI/2:Math.PI/2}))),...Array.from({length:6},(_,i)=>({x:-33.5+i*1.8,y:0,z:5.9,facing:Math.PI}))]);
export const MEETING=ASSEMBLY_SEATS;
const tableBlocks=(x,z,t)=>Math.abs(x-t.x)<t.width/2+.4&&Math.abs(z-t.z)<t.depth/2+.4;
export function walkable(x,z,y=0){
 if(!ELEVATOR_FLOORS.some(v=>Math.abs(v-y)<.12))return false;
 const ground=Math.abs(y)<.12;
 const room=ground&&Object.values(COMMON_ROOMS).find(r=>r.y===0&&Math.abs(x-r.x)<=r.width/2-.45&&Math.abs(z-r.z)<=r.depth/2-.45);
 if(room)return !(room.id==='assembly'?[ASSEMBLY_TABLE]:CANTEEN_TABLES).some(t=>tableBlocks(x,z,t));
 const bridge=ground&&Math.abs(x)>=18&&Math.abs(x)<=23&&z>=4.45&&z<=5.55;
 if(bridge)return true;
 const rearLimit=Math.abs(y-MANAGEMENT.y)<.12&&x<0?-5.65:-5.4;
 if(Math.abs(x)>18.3||z<rearLimit||z>7.1)return false;
 // Only a transport waypoint may enter a shaft. Walking passes in front.
 if(Math.abs(x)<1.8&&z<6.75)return false;
 if(DESKS.some(([dx,dz,dy])=>Math.abs(y-dy)<.2&&Math.abs(x-dx)<1.8&&Math.abs(z-dz)<.94))return false;
 if(Math.abs(y-MANAGEMENT.y)<.12&&x>2){
  if(Math.abs(x-10)<3.35&&Math.abs(z+2.3)<1.2)return false;
  if(Math.hypot(x-14,z-2.5)<1.35)return false;
  // Glass enclosure: .08m panels plus .4m clearance for a walking figure.
  if(Math.abs(x-10.7)<.44&&z>-.99&&z<5.99)return false;
  if(Math.abs(z+.55)<.44&&x>10.3&&x<17.7)return false;
 }
 if(Math.abs(y-MANAGEMENT.y)<.12&&x<0){
  if(Math.abs(x+10)<3.55&&Math.abs(z+4.58)<.7)return false;
  if(Math.abs(Math.abs(x+10)-7.65)<.7&&Math.abs(z-1)<3.05)return false;
  if(Math.abs(Math.abs(x+10)-6.5)<1&&Math.abs(z+4.85)<.9)return false;
 }
 return true;
}
const step=.4,key=(x,z)=>`${x},${z}`;
function nearest(p,canWalk){const x=Math.round(p.x/step),z=Math.round(p.z/step);for(let r=0;r<5;r++)for(let a=-r;a<=r;a++)for(let b=-r;b<=r;b++)if(Math.max(Math.abs(a),Math.abs(b))===r&&canWalk((x+a)*step,(z+b)*step))return[x+a,z+b];return null;}
function gridRoute(from,to,y,avoidExecutive=false){
 const canWalk=(x,z)=>walkable(x,z,y)&&(!avoidExecutive||!insideExecutive(x,z));
 if(!canWalk(from.x,from.z)||!canWalk(to.x,to.z))return[];
 const start=nearest(from,canWalk),end=nearest(to,canWalk);if(!start||!end)return[];
 const queue=[start],parent=new Map([[key(...start),null]]);let cursor=0;
 while(cursor<queue.length){const[x,z]=queue[cursor++];if(x===end[0]&&z===end[1])break;
 for(const[dx,dz]of[[1,0],[-1,0],[0,1],[0,-1],[1,1],[-1,-1],[1,-1],[-1,1]]){const nx=x+dx,nz=z+dz,k=key(nx,nz);if(parent.has(k)||!canWalk(nx*step,nz*step))continue;if(dx&&dz&&(!canWalk(nx*step,z*step)||!canWalk(x*step,nz*step)))continue;parent.set(k,[x,z]);queue.push([nx,nz]);}}
 if(!parent.has(key(...end)))return[];const path=[];let node=end;while(node){path.unshift({x:node[0]*step,y,z:node[1]*step});node=parent.get(key(...node));}
 // Exact lobby/seat endpoints prevent a snap when boarding or sitting.
 path.unshift({x:from.x,y,z:from.z});path.push({x:to.x,y,z:to.z});return path;
}
function floorRoute(from,to,y){
 const fromInside=y===MANAGEMENT.y&&insideExecutive(from.x,from.z),toInside=y===MANAGEMENT.y&&insideExecutive(to.x,to.z);
 if(fromInside!==toInside){
  // Route visitors through the front opening. The exterior half never cuts
  // across the meeting room, including the gap beside the rear glazing.
  const a=gridRoute(from,EXECUTIVE_ENTRY,y,!fromInside),b=gridRoute(EXECUTIVE_ENTRY,to,y,!toInside);
  return a.length&&b.length?[...a,...b]:[];
 }
 return gridRoute(from,to,y);
}
export function findPath(from,to,{elevatorId}={}){
 const fy=ELEVATOR_FLOORS.find(y=>Math.abs(y-(from.y??0))<.12),ty=ELEVATOR_FLOORS.find(y=>Math.abs(y-(to.y??fy))<.12);
 if(fy===undefined||ty===undefined)return[];
 if(fy===ty)return floorRoute(from,to,fy);
 const options=ELEVATORS.filter(e=>!elevatorId||e.id===elevatorId).map(e=>{
  const lobby={x:e.x,z:ELEVATOR_SIZE.landingZ},a=floorRoute(from,lobby,fy),b=floorRoute(lobby,to,ty);
  const distance=p=>p.slice(1).reduce((s,v,i)=>s+Math.hypot(v.x-p[i].x,v.z-p[i].z),0);
  return{e,lobby,a,b,cost:a.length&&b.length?distance(a)+distance(b):Infinity};
 }).sort((a,b)=>a.cost-b.cost||Math.abs(from.x-a.e.x)-Math.abs(from.x-b.e.x));
 const selected=options[0];if(!selected||!Number.isFinite(selected.cost))return[];
 const{e,lobby,a,b}=selected;
 return[...a,{type:'elevator',elevatorId:e.id,...lobby,y:fy,fromY:fy,toY:ty,exit:{...lobby,y:ty}},...b];
}
