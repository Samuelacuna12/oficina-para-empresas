import * as THREE from './vendor/three.module.js';
import {WINGS,MANAGEMENT,SEATS,CHIEF_IDS} from './scene-path.js';
import {ELEVATOR_FLOORS} from './elevator-state.js';
import {buildDisco} from './office-disco.js';
import {buildAmenities} from './office-amenities.js';

export function buildArchitecture(scene,staff,{box,cylinder,solid,group,plastic,labelTexture}){
 const room=group(scene),screens=[],floors=[],roofs=[],pickFloors=[];
 const stone='#d4c6ae',wood='#ad7950',dark='#263b3b',white='#f0ede5';
 const glass=new THREE.MeshStandardMaterial({color:'#a2c6ca',transparent:true,opacity:.17,roughness:.16,metalness:.15,depthWrite:false});
 const glow=new THREE.MeshBasicMaterial({color:'#ffe2a8'});
 const water=new THREE.MeshStandardMaterial({color:'#258eaa',roughness:.16,metalness:.3,transparent:true,opacity:.92});
 function slab(parent,y,z,w,h,d,color){const g=group(parent),side=(w-3.36)/2,min=z-d/2,max=z+d/2;for(const sign of[-1,1])box(g,sign*(1.68+side/2),y,z,side,h,d,color);box(g,0,y,(min+4.78)/2,3.36,h,4.78-min,color);box(g,0,y,(6.42+max)/2,3.36,h,max-6.42,color);return g;}
 function plant(p,x,z,s=1){const g=group(p,x,0,z);cylinder(g,0,.3*s,0,.35*s,.6*s,white,16);for(let k=0;k<6;k++){const leaf=solid(g,new THREE.SphereGeometry(.28,8,6),k%2?'#4d7962':'#355d48',Math.sin(k*2.4)*.22*s,(.8+k*.12)*s,Math.cos(k*2.4)*.22*s);leaf.scale.set(s*.7,s*1.8,s*.5);leaf.rotation.z=Math.sin(k)*.65;}}
 function palm(x,z,s=1){const g=group(room,x,0,z);cylinder(g,0,2*s,0,.16*s,4*s,'#866748',10);for(let k=0;k<9;k++){const leaf=solid(g,new THREE.SphereGeometry(1,8,5),k%2?'#527b54':'#436b48',Math.sin(k*.7)*1.2*s,4*s,Math.cos(k*.7)*1.2*s);leaf.scale.set(.42*s,.16*s,1.8*s);leaf.rotation.set(.22,k*.7,Math.sin(k)*.25);}}
 function chair(p,x,z,angle=0,color='#405957'){const g=group(p,x,0,z);g.rotation.y=angle;box(g,0,.68,0,.85,.18,.78,color);box(g,0,1.12,-.37,.85,.95,.16,color);cylinder(g,0,.32,0,.07,.64,dark,10);for(let k=0;k<5;k++){const f=group(g);f.rotation.y=k*1.256;box(f,0,.12,.25,.08,.08,.6,dark);}for(const side of[-1,1])box(g,side*.46,.9,0,.08,.12,.56,dark);}
 function monitor(p,x,z,w=1.2){box(p,x,1.68,z,w,.8,.1,dark);const m=new THREE.MeshStandardMaterial({color:'#1c3034',emissive:'#548c83',emissiveIntensity:.2});box(p,x,1.68,z+.06,w-.1,.68,.02,m);box(p,x,1.2,z,.1,.35,.12,dark);box(p,x,1.08,z,.5,.05,.32,dark);for(let k=0;k<4;k++)box(p,x-.12,1.9-k*.12,z+.08,w*.5-k*.07,.025,.01,k===0?'#73c5a3':'#abc7bd');return m;}
 function sofa(p,x,z,angle=0){const g=group(p,x,0,z);g.rotation.y=angle;box(g,0,.5,0,3.3,.6,1.25,'#839487');box(g,0,1,-.5,3.3,.8,.22,'#6c8073');for(const side of[-1,1])box(g,side*1.6,.78,0,.22,.7,1.3,'#6c8073');for(let i=-1;i<=1;i++)box(g,i,.86,.05,.93,.18,1,'#a0aea0');}
 // Landscape forms one physical site, while the open front keeps every floor visible.
 box(room,0,-1.05,2,78,1.5,30,'#526750');box(room,0,-.3,2,76,.15,28,'#c0b798');
 box(room,0,-.18,11.5,33,.16,7.7,'#ece3ce');box(room,0,-.08,11.5,27,.16,5.8,dark);box(room,0,.01,11.5,26.4,.08,5.2,water);
 for(let z=9.3;z<14;z+=.65)box(room,0,.06,z,26,.007,.014,'#6cbcc3');
 for(const side of[-1,1]){box(room,side*20,-.05,1,3.8,.14,23,'#a8b18a');for(const z of[-7,3,11])palm(side*20,z,z===3?1.15:.9);for(const z of[9,12]){box(room,side*16.8,.32,z,1.2,.18,2.3,white);const back=box(room,side*16.8,.7,z-.75,1.2,.13,.9,white);back.rotation.x=-.55;}}
 for(let i=0;i<4;i++)box(room,0,-.1-i*.15,16+i*.5,10+i*.8,.2,.7,stone);
 // A few distant, faceted hills give the building a horizon, never cover the UI.
 for(let i=0;i<9;i++){const h=solid(room,new THREE.ConeGeometry(12+(i%3)*2,15+(i%4)*4,5),'#b4c7be',-70+i*18,3,-44-(i%2)*9);h.rotation.y=i;h.castShadow=false;}
 for(let level=0;level<ELEVATOR_FLOORS.length;level++){
  const y=level*6,g=group(room,0,y,0);floors.push(g);
  const floor=slab(g,-.18,.4,39.6,.36,14.6,stone);pickFloors.push(floor);floor.userData.floor=y;
  slab(g,.025,.3,38.7,.05,13.9,'#c1a07a');
  // Parquet joints are restrained; the warm material comes from the reel.
  for(let z=-6.5;z<7.3;z+=.65){if(z>4.78&&z<6.42){for(const x of[-10.515,10.515])box(g,x,.056,z,17.67,.009,.018,'#ae8e69');}else box(g,0,.056,z,38.7,.009,.018,'#ae8e69');}
  box(g,0,2.65,-6.6,39,5.3,.22,'#d9ddd4');
  for(const x of[-19.4,-1.8,1.8,19.4]){if(!level&&Math.abs(x)>19){box(g,x,2.65,-1.375,.22,5.3,10.75,glass);box(g,x,2.65,6.375,.22,5.3,.75,glass);}else box(g,x,2.65,0,.22,5.3,13.5,glass);for(const z of[-6.5,-2,2.5,6.8])box(g,x,2.65,z,.15,5.3,.15,dark);}
  for(const x of[-18,-13,-8,-3,3,8,13,18]){box(g,x,2.8,-6.42,4.7,3.5,.07,glass);box(g,x-2.45,2.8,-6.3,.1,3.7,.1,dark);}
  slab(g,5.35,-.1,40.3,.28,14.8,stone).userData.ceiling=true;box(g,0,5.12,7.08,39.5,.055,.08,glow);
  for(const x of[-19.6,-1.8,1.8,19.6])box(g,x,2.6,7.05,.22,5.2,.22,dark);
  // Front balcony has short edge rails; open centres are the dollhouse cutaway.
  if(level){for(const x of[-17,17]){box(g,x,.65,7.45,4,.85,.06,glass);box(g,x,1.1,7.45,4,.055,.07,dark);}box(g,0,.65,7.45,3.5,.85,.06,glass);}
  // Central circulation core, with visible stairs and lift at the front.
  box(g,0,2.5,-5.4,3.3,5,.25,dark);for(let s=0;s<15&&level<ELEVATOR_FLOORS.length-1;s++)box(g,0,.2+s*.39,-4.8+s*.58,2.6,.14,.62,'#8b7355');
 }
 for(const d of [...WINGS.filter(d=>!d.compact),MANAGEMENT]){
  const parent=floors[d.y/6],g=group(parent,d.x,0,0);
  box(g,0,.075,-.2,15.6,.04,10.8,d.id==='management'?'#b8aa8a':'#c3c6b5');
  box(g,0,2.7,-6.2,15.4,4.8,.15,d.id==='management'?'#254a40':'#445754');
  // Timber slat panel and a large legible architectural sign.
  for(let x=-7.4;x< -4.8;x+=.24)box(g,x,2.6,-6.03,.11,4.7,.12,wood);
  solid(g,new THREE.PlaneGeometry(9.4,.7),labelTexture(d.id==='management'?'GERENCIA':d.name.toUpperCase(),d.id==='management'?'#254a40':'#445754','#f5ecda',{width:1280,height:96,fontSize:64}),.8,4.6,-6);
  box(g,0,.13,5,15.5,.04,.05,d.color);
  plant(g,-7.2,-4.7,1.5);plant(g,7.1,4,1);
  // Low storage, books and an actual wall board give each wing a purpose.
  box(g,6.3,.65,-5.35,2,1.3,.7,'#d4cfbf');for(let k=0;k<6;k++)box(g,5.55+k*.26,1.5,-5.3,.16,.35,.35,[d.color,white,dark][k%3]);
  if(d.id!=='management'){box(g,-4,2.1,-6,3.5,1.35,.15,white);for(let k=0;k<6;k++)box(g,-5.15+k%3*1.1,2.35-Math.floor(k/3)*.55,-5.9,.8,.35,.025,k%2?d.color:'#bab9a5');}
 }
 SEATS.forEach((s,i)=>{
  const p=floors[s.y/6],g=group(p,s.x,0,s.z);
  for(const x of[-1.3,1.3]){box(g,x,.53,0,.1,1.06,1.25,dark);box(g,x,.12,0,.65,.06,1.2,dark);}
  box(g,0,1.05,0,3.2,.15,1.55,wood);box(g,0,1.14,.25,1.7,.025,.75,'#3c504b');screens[i]=s.department==='operations-wing'?null:monitor(g,0,-.38);box(g,0,1.19,.4,.86,.05,.29,'#ccd1c8');box(g,.7,1.18,.42,.17,.06,.24,dark);cylinder(g,-1.2,1.28,.38,.12,.22,(staff[i]?.color||'#17685e'),12);box(g,1.2,1.17,.1,.45,.035,.55,white);chair(p,s.x,s.z+2.1,Math.PI);
  if(['designer','video-editor'].includes(staff[i]?.id))monitor(g,1,-.35,.65);
  if(s.department==='operations-wing'){box(g,0,.12,0,3.8,.05,2.2,'#9cbaac');solid(g,new THREE.PlaneGeometry(2.8,.32),labelTexture('COORDINACIÓN','#17685e','#f4f8ef'),0,1.09,.79);}
 });
 // management suite: private desk, visitor lounge, meeting table and bookcase.
 const boss=floors[MANAGEMENT.y/6];box(boss,10,.1,-2.6,8,.04,4.8,'#cbbb9f');box(boss,10,1.13,-2.3,6.4,.22,1.9,wood);for(const x of[7.4,12.6])box(boss,x,.55,-2.3,.7,1.1,1.6,dark);
 const mon=group(boss,10,0,-2.3);mon.rotation.y=Math.PI;monitor(mon,0,0,1.5);chair(boss,10,-4.7,0,dark);
 solid(boss,new THREE.PlaneGeometry(2.5,.4),labelTexture('GERENTE GENERAL',dark,'#e9d1a3'),10,1.37,-1.32);
 sofa(boss,5.4,1.6,-Math.PI/2);box(boss,7.4,.52,1.7,1.2,.16,2.2,wood);
 cylinder(boss,14,.55,2.5,.35,1.1,dark);cylinder(boss,14,1.15,2.5,1.25,.16,wood,40);
 for(let i=0;i<CHIEF_IDS.length;i++){const a=i*Math.PI*2/CHIEF_IDS.length;chair(boss,14+Math.sin(a)*1.85,2.5+Math.cos(a)*1.85,a);}
 const disco=buildDisco(boss,{box,cylinder,solid,group,labelTexture});
 // Roof is visible in the overview and lifts away when entering a department.
 const roof=group(room,0,ELEVATOR_FLOORS.at(-1)+6,0);roofs.push(roof);box(roof,0,-.25,.1,41,.35,15.3,stone);box(roof,0,0,0,37,.18,12,'#aab49a');
 for(const x of[-17,17])for(const z of[-4,4])plant(roof,x,z,1.3);
 for(let x=-8;x<=8;x+=1)box(roof,x,.3,-2,.07,.12,7,wood);
 solid(room,new THREE.PlaneGeometry(10,.7),labelTexture('GERENCIA / AGENT HQ',dark,'#ece0c8'),0,-.5,17.9);
 const destination=solid(scene,new THREE.RingGeometry(.3,.4,32),new THREE.MeshBasicMaterial({color:'#f0b65c',side:THREE.DoubleSide,transparent:true,opacity:.9}),0,.12,0);destination.rotation.x=-Math.PI/2;destination.visible=false;
 const selection=solid(scene,new THREE.RingGeometry(.65,.74,40),new THREE.MeshBasicMaterial({color:'#50cfa0',side:THREE.DoubleSide,transparent:true,opacity:.9}),0,.13,0);selection.rotation.x=-Math.PI/2;
 room.traverse(o=>{if(o.isMesh&&o.material===glass)o.castShadow=false;});
 const amenities=buildAmenities(room,floors,{box,cylinder,solid,group,labelTexture,chair,plant});
 return {room,screens,destination,selection,floors,roofs,pickFloors,water,disco,...amenities};
}
