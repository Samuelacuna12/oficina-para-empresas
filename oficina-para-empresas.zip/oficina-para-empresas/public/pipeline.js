import {STAGES,taskStage,PRIORITIES} from './task-state.js';
const $=id=>document.getElementById(id);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const statusLabel={pending:'Pendiente',queued:'En cola',running:'Trabajando',done:'Entregado',error:'Requiere atención',cancelled:'Detenido',interrupted:'Interrumpido'};
const safeUrl=s=>{try{const u=new URL(s);return ['https:','http:'].includes(u.protocol)?u.href:null;}catch{return null;}};
function inline(text){return esc(text).replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,(_,title,url)=>`<a href="${url}" target="_blank" rel="noopener">${title}</a>`).replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/`([^`]+)`/g,'<code>$1</code>');}
function readable(text){return text.split(/\n\s*\n/).map(block=>{
  const lines=block.trim().split('\n');
  if(lines.length>=2&&lines[0].trim().startsWith('|')&&/^\s*\|?[\s:|\-]+\|?\s*$/.test(lines[1])&&lines[1].includes('---')){
    const cells=line=>line.trim().replace(/^\||\|$/g,'').split('|').map(c=>c.trim());
    return '<div class="delivery-table-wrap"><table><thead><tr>'+cells(lines[0]).map(c=>'<th>'+inline(c)+'</th>').join('')+'</tr></thead><tbody>'+lines.slice(2).map(line=>'<tr>'+cells(line).map(c=>'<td>'+inline(c)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';
  }
  if(/^#{1,4}\s/.test(block))return block.split('\n').map(line=>/^#{1,4}\s/.test(line)?`<h3>${inline(line.replace(/^#+\s/,''))}</h3>`:`<p>${inline(line)}</p>`).join('');
  if(block.split('\n').every(l=>/^[-*]\s/.test(l)))return '<ul>'+block.split('\n').map(l=>'<li>'+inline(l.slice(2))+'</li>').join('')+'</ul>';
  return '<p>'+block.split('\n').map(inline).join('<br>')+'</p>';
}).join('');}

export class Pipeline {
  constructor({api,refresh,toast,time}){
    Object.assign(this,{api,refresh,toast,time,state:null,current:null,tab:'delivery',version:null,dragging:null,editing:false,revising:false,detailStamp:'',quick:'all',view:'board',renderStamp:''});
    this.board=$('kanban-board');
    document.querySelectorAll('[data-board-view]').forEach(b=>b.onclick=()=>{this.view=b.dataset.boardView;document.querySelectorAll('[data-board-view]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));this.render();});
    document.querySelectorAll('[data-quick]').forEach(b=>b.onclick=()=>{this.quick=b.dataset.quick;document.querySelectorAll('[data-quick]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));this.render();});
    $('board-clear').onclick=()=>{$('board-search').value='';$('board-agent').value='';$('board-department').value='';this.quick='all';document.querySelectorAll('[data-quick]').forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.quick==='all')));this.render();};this.dialog=$('task-dialog');this.newDialog=$('new-task-dialog');
    $('board-new').onclick=()=>this.create();$('board-search').oninput=()=>this.render();$('board-agent').onchange=()=>this.render();
    $('board-department').onchange=()=>{$('board-agent').value='';this.render();};
    $('board-jumps').onclick=e=>{const b=e.target.closest('[data-column]');if(b)this.jump(b.dataset.column);};
    $('board-review-link').onclick=()=>this.jump('review');
    this.board.addEventListener('click',e=>{const c=e.target.closest('[data-open-card]');if(c)this.open(c.dataset.openCard);if(e.target.closest('[data-add-card]'))this.create();});
    this.board.addEventListener('dragstart',e=>{const card=e.target.closest('[data-open-card]');if(!card)return;this.dragging=card.dataset.openCard;e.dataTransfer.setData('text/plain',this.dragging);e.dataTransfer.effectAllowed='move';card.classList.add('dragging');});
    this.board.addEventListener('dragover',e=>{const c=e.target.closest('[data-stage]');if(c&&this.dragging){e.preventDefault();e.dataTransfer.dropEffect='move';this.board.querySelectorAll('.drop-target').forEach(c=>c.classList.remove('drop-target'));c.classList.add('drop-target');}});
    this.board.addEventListener('drop',async e=>{const c=e.target.closest('[data-stage]');if(!c||!this.dragging)return;e.preventDefault();const id=this.dragging;this.dragging=null;await this.action(id,'move',{stage:c.dataset.stage});this.render();});
    this.board.addEventListener('dragend',()=>{this.dragging=null;this.renderStamp='';this.render();});
    this.dialog.addEventListener('close',()=>{this.current=null;this.editing=false;this.revising=false;});
    this.dialog.addEventListener('click',e=>this.detailClick(e));
    this.dialog.addEventListener('change',e=>{if(e.target.id==='delivery-version'){this.version=Number(e.target.value);this.renderDetail(true);}});
    this.dialog.addEventListener('submit',async e=>{
      e.preventDefault();const f=e.target,b=e.submitter;b.disabled=true;
      if(f.id==='card-edit-form')await this.action(this.current,'save',Object.fromEntries(new FormData(f)),true);
      if(f.id==='card-revise-form')await this.action(this.current,'revise',Object.fromEntries(new FormData(f)),true);
      if(b.isConnected)b.disabled=false;
    });
    $('new-task-form').addEventListener('submit',async e=>{
      e.preventDefault();const b=e.submitter;b.disabled=true;
      try{const form=Object.fromEntries(new FormData(e.target));const t=await this.api('/api/board',{...form,start:b.value==='start'});this.newDialog.close();await this.refresh();location.hash='tablero';this.open(t.id);this.toast(t.status==='pending'?'Tarjeta guardada en Pendientes.':'Tarea asignada. Su entrega aparecerá en esta tarjeta.');}
      catch(error){this.toast(error.message,true);}finally{b.disabled=false;}
    });
  }
  agent(id){return this.state.agents.find(a=>a.id===id);}
  options(selected){return this.state.departments.map(d=>`<optgroup label="${esc(d.name)}">${this.state.agents.filter(a=>a.department===d.id).map(a=>`<option value="${a.id}" ${a.id===selected?'selected':''}>${esc(a.person)} · ${esc(a.name)}</option>`).join('')}</optgroup>`).join('');}
  update(state){
    const old=this.state;this.state=state;
    if(!$('board-agent').options.length)$('board-agent').innerHTML='<option value="">Todos los agentes</option>'+this.options('');
    if(!$('board-department').options.length)$('board-department').innerHTML='<option value="">Todos los departamentos</option>'+state.departments.map(d=>`<option value="${d.id}">${esc(d.name)}</option>`).join('');
    const review=state.tasks.filter(t=>taskStage(t)==='review').length;$('board-count').textContent=review;$('board-review-count').textContent=review;
    if(old){const arrived=state.tasks.find(t=>t.status==='done'&&old.tasks.some(p=>p.id===t.id&&(p.status!=='done'||p.deliveries?.length!==t.deliveries?.length)));if(arrived)this.toast(this.agent(arrived.agent).person.split(' ·')[0]+' entregó «'+arrived.title+'». Está en Para revisar.');}
    if(!this.dragging)this.render();this.renderDetail();
  }
  render(){
    if(!this.state)return;
    const q=$('board-search').value.toLocaleLowerCase(),agent=$('board-agent').value,department=$('board-department').value;
    const list=this.state.tasks.filter(t=>(!agent||t.agent===agent)&&(!department||this.agent(t.agent).department===department)&&(!q||(t.title+' '+t.text).toLocaleLowerCase().includes(q))&&(this.quick==='all'||this.quick==='review'&&taskStage(t)==='review'||this.quick==='high'&&t.priority==='high'));
    $('board-total').textContent=`${list.length} ${list.length===1?'tarjeta':'tarjetas'}`;
    $('board-jumps').innerHTML=STAGES.map(s=>`<button type="button" data-column="${s.id}">${s.short}<span>${list.filter(t=>taskStage(t)===s.id).length}</span></button>`).join('');
    this.board.classList.toggle('list-view',this.view==='list');
    const stamp=JSON.stringify([list.map(t=>[t.id,t.title,t.text,t.status,t.priority,t.agent,t.dueDate,t.deliveries?.length,t.approvedAt]),this.quick,this.view,agent,department,q]);if(stamp===this.renderStamp)return;this.renderStamp=stamp;
    this.board.innerHTML=STAGES.map(s=>{
      const cards=list.filter(t=>taskStage(t)===s.id).sort((a,b)=>({high:0,normal:1,low:2}[a.priority]-{high:0,normal:1,low:2}[b.priority]));
      if(this.view==='list'&&!cards.length)return '';
      return `<section class="kanban-column stage-${s.id}" data-stage="${s.id}" aria-label="${s.name}"><div class="column-heading"><span class="stage-dot"></span><h2>${s.name}</h2><span class="column-count">${cards.length}</span></div><p class="column-hint">${s.hint}</p><div class="column-cards">${cards.map(t=>this.card(t)).join('')||`<div class="column-empty">${q||agent||department||this.quick!=='all'?'No hay tarjetas con este filtro.':{pending:'Crea una tarjeta y elige quién la hará.',progress:'Arrastra aquí una pendiente para que el agente empiece.',review:'Los resultados llegarán aquí automáticamente.',complete:'Tus entregas aprobadas aparecerán aquí.'}[s.id]}</div>`}</div>${s.id==='pending'?'<button class="add-card" type="button" data-add-card>＋ Añadir tarjeta</button>':''}</section>`;
    }).join('');
    if(this.view==='list'&&!list.length)this.board.innerHTML='<div class="column-empty">No hay tareas con estos filtros. Puedes cambiarlos o limpiar la búsqueda.</div>';
  }
  card(t){
    const a=this.agent(t.agent),stage=taskStage(t),delivery=t.deliveries?.at(-1),error=['error','cancelled','interrupted'].includes(t.status);
    const state=stage==='complete'?'Aprobado':stage==='review'?`Entrega lista · v${delivery?.version||1}`:t.status==='queued'?'En cola':t.status==='running'?'El agente está trabajando':error?statusLabel[t.status]:'Lista para asignar';
    return `<button type="button" class="kanban-card ${error?'card-attention':''}" data-open-card="${t.id}" draggable="true" aria-label="Abrir tarjeta: ${esc(t.title)}"><div class="card-labels"><span class="card-department" style="--dept-color:${a.color}">${esc(a.departmentName||this.state.departments.find(d=>d.id===a.department)?.name||'Equipo')}</span><span class="priority-${t.priority}">${PRIORITIES[t.priority]||'Normal'}</span>${t.kind!=='analysis'?'<span class="card-type">Correo</span>':''}<span class="card-grip" aria-hidden="true">⠿</span></div><h3>${esc(t.title)}</h3><p class="card-preview">${esc(t.text.slice(0,110))}${t.text.length>110?'…':''}</p><div class="card-state ${stage}">${stage==='review'?'▤ ':stage==='complete'?'✓ ':t.status==='running'?'◉ ':''}${esc(state)}</div><div class="card-bottom"><span class="card-person"><i style="--agent-color:${a.color}">${esc(a.person[0])}</i><span>${esc(a.person.split(' ·')[0])}<small>${esc(a.name)}</small></span></span>${t.dueDate?`<span class="card-date">${esc(t.dueDate.split('-').reverse().slice(0,2).join('/'))}</span>`:''}${delivery?`<span class="card-attachment" aria-label="${t.deliveries.length} versiones">▤ ${t.deliveries.length}</span>`:''}</div></button>`;
  }
  jump(stage){$('board-clear').click();if(stage==='review'){this.quick='review';document.querySelectorAll('[data-quick]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.quick==='review')));this.render();}location.hash='tablero';this.board.querySelector(`[data-stage="${stage}"]`)?.scrollIntoView({behavior:matchMedia('(prefers-reduced-motion: reduce)').matches?'instant':'smooth',block:'nearest',inline:'center'});}
  create(agent){
    if(!this.state)return;agent??=$('board-agent').value||this.state.agents.find(a=>a.department===$('board-department').value)?.id||'director';$('new-task-form').reset();$('new-task-agent').innerHTML=this.options(agent);this.newDialog.showModal();$('new-task-title').focus();
  }
  open(id){
    const t=this.state?.tasks.find(t=>t.id===id);if(!t)return;this.current=id;this.editing=false;this.revising=false;this.tab=t.deliveries?.length?'delivery':'instructions';this.version=t.deliveries?.at(-1)?.version||null;this.renderDetail(true);if(!this.dialog.open)this.dialog.showModal();
  }
  async action(id,action,extra={},closeForms=false){
    try{await this.api('/api/task-action',{id,action,...extra});if(closeForms){this.editing=false;this.revising=false;}await this.refresh();this.renderDetail(true);this.toast({start:'El agente recibió la tarea.',approve:'Entrega aprobada. Tarjeta en Terminado.',reopen:'Tarjeta devuelta a Para revisar.',revise:'Cambios enviados al agente. Conservamos la versión anterior.',save:'Tarjeta actualizada.',move:'Tarjeta movida.'}[action]||'Listo.');return true;}
    catch(e){this.toast(e.message,true);return false;}
  }
  async detailClick(e){
    const button=e.target.closest('[data-card-action]');if(!button)return;const act=button.dataset.cardAction;
    if(act==='close'){this.dialog.close();return;}
    if(['delivery','instructions','history'].includes(act)){this.tab=act;this.editing=false;this.revising=false;this.renderDetail(true);return;}
    if(act==='edit'){this.editing=true;this.revising=false;this.renderDetail(true);return;}
    if(act==='request-changes'){this.revising=true;this.editing=false;this.renderDetail(true);$('revision-feedback').focus();return;}
    if(act==='cancel-form'){this.editing=false;this.revising=false;this.renderDetail(true);return;}
    const t=this.state.tasks.find(t=>t.id===this.current);if(!t)return;
    if(act==='copy'){const d=t.deliveries.find(d=>d.version===this.version)||t.deliveries.at(-1);try{await navigator.clipboard.writeText(d.text);this.toast('Entrega copiada.');}catch{this.toast('No se pudo copiar. Puedes descargar la entrega.',true);}return;}
    button.disabled=true;
    if(act==='stop'){try{await this.api('/api/cancel/'+t.id,{});await this.refresh();this.toast('Tarea detenida. Puedes iniciarla de nuevo desde esta tarjeta.');}catch(error){this.toast(error.message,true);}}
    else await this.action(t.id,act);
    if(button.isConnected)button.disabled=false;
  }
  renderDetail(force=false){
    const t=this.state?.tasks.find(t=>t.id===this.current);if(!t)return;
    const stamp=JSON.stringify(t);if(!force&&(stamp===this.detailStamp||this.editing||this.revising))return;this.detailStamp=stamp;
    if(!force&&t.deliveries?.length&&this.version!==t.deliveries.at(-1).version&&['queued','running'].includes(this.lastDetailStatus))this.version=t.deliveries.at(-1).version;
    this.lastDetailStatus=t.status;
    const a=this.agent(t.agent),stage=STAGES.find(s=>s.id===taskStage(t)),running=['queued','running'].includes(t.status),canEdit=!running&&t.status!=='done'&&t.kind==='analysis';
    $('task-dialog-heading').textContent=t.title;$('task-dialog-stage').textContent=stage.name;$('task-dialog-stage').className='detail-stage '+stage.id;
    $('card-tabs').innerHTML=[['delivery','Entrega'],['instructions','Instrucciones'],['history','Actividad y versiones']].map(([id,name])=>`<button type="button" role="tab" aria-selected="${this.tab===id}" data-card-action="${id}">${name}${id==='delivery'&&t.deliveries.length?` <span>${t.deliveries.length}</span>`:''}</button>`).join('');
    $('card-sidebar').innerHTML=`<label>Agente responsable</label><div class="detail-owner"><i style="--agent-color:${a.color}">${esc(a.person[0])}</i><span><strong>${esc(a.person)}</strong><small>${esc(a.name)}</small></span></div><dl><dt>Prioridad</dt><dd>${PRIORITIES[t.priority]}</dd><dt>Fecha objetivo</dt><dd>${t.dueDate?esc(t.dueDate):'Sin fecha'}</dd><dt>Estado del agente</dt><dd>${statusLabel[t.status]}</dd></dl><div class="detail-buttons">${canEdit?'<button type="button" class="button secondary" data-card-action="edit">Editar y reasignar</button>':''}${!running&&t.status!=='done'&&t.kind!=='correo-draft'?'<button type="button" class="button primary" data-card-action="start">Poner a trabajar →</button>':''}${running?'<button type="button" class="button secondary" data-card-action="stop">Detener tarea</button>':''}${t.status==='done'&&!t.approvedAt?'<button type="button" class="button primary" data-card-action="approve">Aprobar entrega ✓</button>':''}${t.status==='done'&&t.approvedAt?'<button type="button" class="button secondary" data-card-action="reopen">Volver a revisar</button>':''}${t.status==='done'&&t.kind==='analysis'?'<button type="button" class="button secondary" data-card-action="request-changes">Pedir cambios</button>':''}</div><p class="detail-help">El agente entrega aquí. Aprobar cierra la tarea; no envía correos.</p>`;
    if(this.editing){$('card-body').innerHTML=`<h3 class="detail-section-title">Editar tarjeta</h3><form id="card-edit-form">${this.fields(t)}<div class="button-row"><button class="button primary" type="submit">Guardar cambios</button><button class="button secondary" type="button" data-card-action="cancel-form">Cancelar</button></div></form>`;return;}
    if(this.revising){$('card-body').innerHTML=`<h3 class="detail-section-title">Pedir una nueva versión</h3><p class="detail-intro">La entrega actual se conserva. El agente recibirá tus indicaciones y dejará aquí la versión corregida.</p><form id="card-revise-form"><label for="revision-agent">¿Quién hace los cambios?</label><select id="revision-agent" name="agent">${this.options(t.agent)}</select><label for="revision-feedback">¿Qué debe cambiar?</label><textarea id="revision-feedback" name="feedback" rows="7" maxlength="5000" required placeholder="Ej.: hazlo más breve, añade el siguiente paso y conserva los precios…"></textarea><div class="button-row"><button type="submit" class="button primary">Solicitar cambios al agente</button><button type="button" class="button secondary" data-card-action="cancel-form">Cancelar</button></div></form>`;return;}
    if(this.tab==='instructions'){$('card-body').innerHTML=`<h3 class="detail-section-title">Lo que le pediste</h3><div class="delivery-prose">${readable(t.text)}</div>${t.revisionNotes.length?'<h3 class="detail-section-title">Cambios solicitados</h3>'+t.revisionNotes.map(n=>`<div class="revision-note"><small>${this.time(n.at)}</small><p>${esc(n.text)}</p></div>`).join(''):''}`;return;}
    if(this.tab==='history'){$('card-body').innerHTML=`<h3 class="detail-section-title">Versiones guardadas</h3>${t.deliveries.length?t.deliveries.map(d=>`<div class="version-row"><span><strong>Versión ${d.version}</strong><small>${esc(this.agent(d.agent)?.person||'Agente')} · ${this.time(d.at)}</small></span><a href="/result/${t.id}?version=${d.version}" class="small-button">Descargar</a></div>`).join(''):'<p class="detail-intro">Todavía no hay entregas.</p>'}<h3 class="detail-section-title history-heading">Actividad</h3><ol class="task-timeline">${[...(t.activityLog||[])].reverse().map(l=>`<li><span>${this.time(l.at)}</span><p>${esc(l.note)}</p></li>`).join('')||`<li><span>${this.time(t.createdAt)}</span><p>Tarea anterior incorporada al tablero. Su entrega se conserva.</p></li>`}</ol>`;return;}
    const d=t.deliveries.find(d=>d.version===this.version)||t.deliveries.at(-1);if(d)this.version=d.version;
    const status=running?`<div class="delivery-progress"><span class="dot"></span><div><strong>${t.status==='queued'?'En cola para '+esc(a.person.split(' ·')[0]):esc(a.person.split(' ·')[0])+' está trabajando'}</strong><p>${esc(t.activity)}. La entrega aparecerá aquí automáticamente.${d?' La versión anterior sigue disponible abajo.':''}</p></div></div>`:t.error?`<div class="task-error">${esc(t.error)}</div>`:'';
    let correo='';if(t.correoDraft?.web_url&&safeUrl(t.correoDraft.web_url)?.startsWith('https://mail.google.com/'))correo=`<a class="button secondary" href="${esc(t.correoDraft.web_url)}" target="_blank" rel="noopener">Abrir borrador en correo ↗</a>`;
    $('card-body').innerHTML=status+(d?`<div class="delivery-heading"><span class="delivery-file">▤</span><div><strong>Entrega del agente</strong><small>${this.time(d.at)} · guardada en este computador</small></div><label class="version-select">Versión<select id="delivery-version" aria-label="Versión de la entrega">${t.deliveries.map(v=>`<option value="${v.version}" ${v.version===d.version?'selected':''}>${v.version}${v===t.deliveries.at(-1)?' · última':''}</option>`).join('')}</select></label></div><div class="delivery-actions"><button type="button" class="button secondary" data-card-action="copy">Copiar entrega</button><a class="button secondary" href="/result/${t.id}?version=${d.version}">Descargar .txt</a>${correo}</div><div class="delivery-prose">${readable(d.text)}</div>`:!running?'<div class="delivery-empty"><span>▤</span><h3>Este es el lugar de la entrega.</h3><p>Pulsa «Poner a trabajar». Cuando termine, el agente guardará aquí su resultado y la tarjeta pasará a Para revisar.</p></div>':'');
  }
  fields(t){return `<label for="edit-title">Título</label><input id="edit-title" name="title" value="${esc(t.title)}" maxlength="180" required><label for="edit-text">Instrucciones y resultado esperado</label><textarea id="edit-text" name="text" rows="6" maxlength="10000" required>${esc(t.text)}</textarea><label for="edit-agent">Agente responsable</label><select id="edit-agent" name="agent">${this.options(t.agent)}</select><div class="field-pair"><div><label for="edit-priority">Prioridad</label><select id="edit-priority" name="priority">${Object.entries(PRIORITIES).map(([key,name])=>`<option value="${key}" ${t.priority===key?'selected':''}>${name}</option>`).join('')}</select></div><div><label for="edit-due">Fecha objetivo</label><input id="edit-due" name="dueDate" type="date" value="${esc(t.dueDate)}"></div></div>`;}
}
