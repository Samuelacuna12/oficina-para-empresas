import * as THREE from './vendor/three.module.js';
import {DESKS,HOMES,SEATS,WINGS,MANAGEMENT,MANAGER_HOME,MANAGER_MEETING,CHIEF_IDS,EXEC_MEETING,COMMON_ROOMS,DISCO_SPOTS,DISCO_MANAGER_SPOT,ASSEMBLY_SEATS,CANTEEN_SEATS,findPath,walkable} from './scene-path.js';
import {buildArchitecture} from './office-architecture.js';
import {DiscoAudio} from './office-disco.js';
import {buildElevators} from './office-elevators.js';
import {ELEVATOR_FLOORS} from './elevator-state.js';

const matCache=new Map(),boxGeo=new THREE.BoxGeometry(1,1,1);
const plastic=color=>{if(!matCache.has(color))matCache.set(color,new THREE.MeshStandardMaterial({color,roughness:.31,metalness:0}));return matCache.get(color);};
function solid(parent,geo,color,x=0,y=0,z=0){const m=new THREE.Mesh(geo,typeof color==='string'?plastic(color):color);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
function box(parent,x,y,z,w,h,d,color){const m=solid(parent,boxGeo,color,x,y,z);m.scale.set(w,h,d);return m;}
function cylinder(parent,x,y,z,r,h,color,n=24){return solid(parent,new THREE.CylinderGeometry(r,r,h,n),color,x,y,z);}
function group(parent,x=0,y=0,z=0){const g=new THREE.Group();g.position.set(x,y,z);parent.add(g);return g;}
function labelTexture(text,bg='#f4f8fc',fg='#243d50',{width=512,height=128,fontSize=43}={}){
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
  const c=canvas.getContext('2d');c.fillStyle=bg;c.fillRect(0,0,width,height);c.fillStyle=fg;
  let size=fontSize;c.font=`600 ${size}px system-ui`;while(c.measureText(text).width>width-40&&size>18)c.font=`600 ${--size}px system-ui`;
  c.textAlign='center';c.textBaseline='middle';c.fillText(text,width/2,height/2);
  const t=new THREE.CanvasTexture(canvas);t.colorSpace=THREE.SRGBColorSpace;return new THREE.MeshStandardMaterial({map:t,roughness:.6});
}
function faceTexture(glasses=false){
  const c=document.createElement('canvas');c.width=256;c.height=128;const p=c.getContext('2d');
  p.fillStyle='#161d26';for(const x of[90,166]){p.beginPath();p.ellipse(x,41,7,10,0,0,7);p.fill();}
  p.lineWidth=5;p.lineCap='round';p.strokeStyle='#161d26';p.beginPath();p.arc(128,62,29,.15,Math.PI-.15);p.stroke();
  if(glasses){p.lineWidth=4;for(const x of[90,166]){p.beginPath();p.roundRect(x-24,20,48,39,10);p.stroke();}p.beginPath();p.moveTo(114,37);p.lineTo(142,37);p.stroke();}
  const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return new THREE.MeshBasicMaterial({map:t,transparent:true,depthWrite:false,side:THREE.DoubleSide});
}
function figure(parent,color,index){
  const root=group(parent),body=group(root),yellow='#ffd631',pants=index===2?'#426c85':'#23384c';
  const legs=[-1,1].map(side=>{const g=group(body,side*.205,.72,0);box(g,0,-.27,0,.36,.57,.38,pants);box(g,0,-.54,.09,.37,.16,.55,pants);return g;});
  box(body,0,.73,0,.83,.19,.43,pants);
  const shape=new THREE.Shape();shape.moveTo(-.47,0);shape.lineTo(.47,0);shape.lineTo(.34,.64);shape.lineTo(-.34,.64);shape.closePath();
  const torso=solid(body,new THREE.ExtrudeGeometry(shape,{depth:.42,bevelEnabled:true,bevelSegments:2,steps:1,bevelSize:.035,bevelThickness:.035}),color,0,.82,-.21);
  box(body,0,1.3,.235,.17,.2,.018,'#fafaf5');box(body,0,1.13,.24,.055,.22,.023,index===5?'#e65047':'#e2ecf0');
  box(body,.23,1.08,.24,.13,.11,.025,'#f7f5ed');
  cylinder(body,0,1.55,0,.145,.15,yellow);
  const head=group(body,0,1.83,0);cylinder(head,0,0,0,.33,.47,yellow,32);cylinder(head,0,.27,0,.145,.1,yellow);
  const face=solid(head,new THREE.CylinderGeometry(.335,.335,.38,24,1,true,-.85,1.7),faceTexture(index===3||index===5));
  if(index!==5){
    const hairColor=index===2?'#b86a26':index===3?'#543d30':'#293239';
    const hair=solid(head,new THREE.SphereGeometry(.35,24,12,0,Math.PI*2,0,Math.PI/2),hairColor,0,.17,0);hair.scale.y=.65;
    box(head,-.23,.15,-.11,.14,.25,.32,hairColor);
    if(index===0||index===4){const tail=solid(head,new THREE.SphereGeometry(.16,12,8),hairColor,0,-.05,-.35);tail.scale.y=1.6;}
  }
  const arms=[-1,1].map(side=>{
    const g=group(body,side*.45,1.39,0);g.rotation.z=side*.11;
    const sleeve=cylinder(g,0,-.21,0,.135,.43,color,12);sleeve.rotation.z=side*.1;
    cylinder(g,side*.025,-.45,.04,.092,.17,yellow,12);
    const hand=solid(g,new THREE.TorusGeometry(.11,.047,8,16,Math.PI*1.6),yellow,side*.03,-.55,.06);hand.rotation.z=-Math.PI*.3;
    return g;
  });
  root.traverse(o=>{if(o.isMesh)o.userData.agentIndex=index;});
  return {root,body,head,legs,arms};
}

export class OfficeWorld {
  constructor(host,{onSelect,onAssign,onResult,onNotice,onReview,onContext,onGadget,agents}){
    this.host=host;this.staff=agents;this.department=null;this.roomId=null;this.elevatorView=false;this.executiveView=false;this.pan={x:0,z:0};this.deskLabels=[];this.wingLabels=[];this.spaceLabels=[];this.callbacks={onSelect,onAssign,onResult,onNotice,onReview,onContext,onGadget};this.agents=[];this.selected='company-manager';this.tasks=[];this.observedTasks=new Map();
    this.reduced=matchMedia('(prefers-reduced-motion: reduce)');
    this.partyAll=false;this.partyEnabled=true;this.discoAudio=new DiscoAudio();this.time=0;this.last=0;this.paused=false;this.visible=true;this.azimuth=.25;this.elevation=.2;this.zoom=1;this.packets=[];this.meetingUntil=0;
    host.innerHTML=`<div class="world-loading">Construyendo tu oficina…</div><div class="world-labels"></div><div class="world-speech" role="status" aria-live="polite" hidden></div><div class="world-card" hidden><div><span class="world-card-kicker"></span><strong></strong><p></p></div><div class="world-card-actions"><button type="button" class="small-button world-assign">Asignar tarea →</button><button type="button" class="small-button world-result">Ver último resultado</button><button type="button" class="world-close" aria-label="Cerrar ficha del agente">×</button></div></div>`;
    this.labels=host.querySelector('.world-labels');this.speech=host.querySelector('.world-speech');this.card=host.querySelector('.world-card');
    try{this.renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});}catch(e){host.querySelector('.world-loading').textContent='La vista 3D necesita aceleración gráfica. Puedes seguir asignando tareas desde los botones del equipo.';throw e;}
    this.renderer.setPixelRatio(Math.min(devicePixelRatio,1.65));this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=THREE.PCFSoftShadowMap;this.renderer.setClearColor('#d7e2df',1);
    this.renderer.toneMapping=THREE.ACESFilmicToneMapping;this.renderer.toneMappingExposure=1.08;
    this.canvas=this.renderer.domElement;this.canvas.setAttribute('aria-label','Oficina 3D. Selecciona un personaje o toca el suelo para moverlo. Flechas para mover la vista, rueda del mouse para acercar o alejar y arrastra para girar.');this.canvas.tabIndex=0;host.prepend(this.canvas);
    this.scene=new THREE.Scene();this.camera=new THREE.OrthographicCamera(-12,12,9,-9,.1,240);this.ray=new THREE.Raycaster();this.pointer=new THREE.Vector2();this.ground=new THREE.Plane(new THREE.Vector3(0,1,0),0);
    this.scene.add(new THREE.HemisphereLight('#eaf6ff','#6a7661',1.9));
    const sun=new THREE.DirectionalLight('#fff2d9',2.5);sun.position.set(-22,40,32);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);Object.assign(sun.shadow.camera,{left:-42,right:42,top:50,bottom:-45,near:.5,far:120});sun.shadow.normalBias=.04;sun.shadow.bias=-.0003;this.scene.add(sun);
    const fill=new THREE.DirectionalLight('#c9e6ff',.8);fill.position.set(8,8,-5);this.scene.add(fill);
    this.buildRoom();this.buildSpaceControls();this.pointerEvents();this.card.querySelector('.world-close').onclick=()=>{this.card.hidden=true;};
    this.card.querySelector('.world-assign').onclick=()=>this.selected==='company-manager'?this.callbacks.onReview():this.callbacks.onAssign(this.selected);
    this.card.querySelector('.world-result').onclick=()=>{if(this.selected==='company-manager'){this.gatherChiefs();return;}const t=this.tasks.find(t=>t.agent===this.selected&&t.result);if(t)this.callbacks.onResult(t.id);};
    this.resizeObserver=new ResizeObserver(()=>this.resize());this.resizeObserver.observe(host);
    this.intersection=new IntersectionObserver(es=>{this.visible=es[0]?.isIntersecting;});this.intersection.observe(host);
    document.addEventListener('visibilitychange',()=>{if(document.hidden)this.discoAudio.pause();else if(this.discoAudio.enabled&&!this.paused&&this.partyEnabled)this.discoAudio.start().catch(()=>{});});
    this.reduced.addEventListener('change',e=>{this.elevators.setReducedMotion(e.matches);});
    host.querySelector('.world-loading').remove();this.resize();this.raf=requestAnimationFrame(t=>this.frame(t));
  }
  buildRoom(){
    Object.assign(this,buildArchitecture(this.scene,this.staff,{box,cylinder,solid,group,plastic,labelTexture}));
    this.elevators=buildElevators(this.scene,{box,solid,group,labelTexture},{reducedMotion:this.reduced.matches});
    for(const d of [...WINGS.filter(d=>!d.compact),MANAGEMENT]){const tag=document.createElement('button');tag.type='button';tag.className='wing-label';tag.style.setProperty('--wing-color',d.color);tag.textContent=d.id==='management'?`P${d.y/6+1} · Gerencia / la gerencia`:`P${d.y/6+1} · ${d.name} · ${d.count}`;tag.setAttribute('aria-label',d.id==='management'?'Entrar a mi oficina de Gerencia':'Ver ala de '+d.name);tag.onclick=()=>this.focusDepartment(d.id);this.labels.append(tag);this.wingLabels.push({el:tag,x:d.x,y:d.y+4.55,z:6.9});}
    for(const s of[{id:'disco',title:'P5 · Discoteca / After Hours',x:-10,y:28.8,z:6.2,color:'#e8bd7f'},{id:'assembly',title:'Zona común · Sala de equipo',x:29,y:5.1,z:6.2,color:'#a0c2ad'},{id:'canteen',title:'Comedor · Café',x:-29,y:5.1,z:6.2,color:'#d5be8c'},{id:'chiefs',title:'Sala de jefes',x:15,y:MANAGEMENT.y+3.3,z:5.6,color:'#d5be8c'}]){
      const el=document.createElement('button');el.type='button';el.className='wing-label room-label';el.dataset.room=s.id;el.style.setProperty('--wing-color',s.color);el.textContent=s.title;el.setAttribute('aria-label','Entrar a '+s.title);el.onclick=()=>s.id==='chiefs'?this.focusChiefs():this.focusRoom(s.id);this.labels.append(el);this.spaceLabels.push({...s,el});
    }
    const data={id:'company-manager',person:'Tu empresa',name:'Gerencia',department:'management',departmentName:'Gerencia',job:'La gerencia. Los jefes de departamento reportan aquí.',color:'#25483f'};
    const f=figure(this.scene,data.color,this.staff.length);f.root.position.set(MANAGER_HOME.x,MANAGER_HOME.y,MANAGER_HOME.z);
    const tag=document.createElement('button');tag.className='world-tag owner-tag';tag.innerHTML='<span>la gerencia</span><small>Gerencia</small>';tag.onclick=()=>this.interact(data.id);this.labels.append(tag);
    this.manager={...f,data,index:this.staff.length,home:MANAGER_HOME,path:[],mode:'idle',next:Infinity,phase:1,waveUntil:3,holdUntil:Infinity,tag,status:'Tu puesto',task:null};
    const label=document.createElement('button');label.className='desk-label manager-desk-label';label.innerHTML='<strong>Tu empresa</strong><small>Gerencia · Tú</small>';label.setAttribute('aria-label','Mi escritorio: Tu empresa, gerencia');label.onclick=()=>this.interact(data.id);this.labels.append(label);this.managerDeskLabel=label;
  }
  buildSpaceControls(){
    const nav=document.createElement('nav');nav.className='world-space-controls';nav.setAttribute('aria-label','Salas y ascensores');
    nav.innerHTML=`<div class="world-room-controls"><button type="button" data-room="assembly">Zona común · Sala de equipo</button><button type="button" data-room="canteen">Comedor</button><button type="button" data-room="chiefs">Sala de jefes</button><button type="button" data-room="disco">Discoteca · Piso 5</button><button type="button" class="party-time-trigger" data-action="party-time" aria-pressed="false"><span aria-hidden="true">✦</span> Party Time</button><button type="button" data-room="elevators">Ascensores</button><button type="button" data-action="gather">Reunir a todos</button><button type="button" data-action="break">Pausa de café</button><button type="button" data-action="tv">Abrir televisor</button></div><fieldset class="world-lift-controls"><legend>Ascensor · <span class="world-lift-person">la gerencia</span></legend><label>Cabina <select aria-label="Cabina del ascensor"><option value="">La más cercana</option><option value="lift-west">A · Izquierda</option><option value="lift-east">B · Derecha</option></select></label>${ELEVATOR_FLOORS.map((y,i)=>`<button type="button" data-floor="${y}">Piso ${i+1}</button>`).join('')}</fieldset><output class="world-lift-status" role="status" aria-live="polite"></output><section class="world-disco-controls" hidden aria-label="Controles de la discoteca"><div><span class="disco-eyebrow">AFTER HOURS / PISO 05</span><strong class="world-disco-count">La pista se está preparando</strong><small class="world-disco-explainer">Bailan los agentes libres. Las tareas tienen prioridad.</small></div><div class="world-disco-actions"><button type="button" data-action="party-end" hidden>Terminar fiesta</button><button type="button" data-action="party" aria-pressed="true">Fiesta automática: activa</button><button type="button" data-action="music" aria-pressed="false">Encender música</button></div></section>`;
    nav.querySelectorAll('[data-room]').forEach(b=>b.onclick=()=>b.dataset.room==='chiefs'?this.focusChiefs():b.dataset.room==='elevators'?this.focusElevators():this.focusRoom(b.dataset.room));
    nav.querySelector('[data-action="gather"]').onclick=()=>this.gatherAll();nav.querySelector('[data-action="break"]').onclick=()=>this.takeBreak();
    nav.querySelector('[data-action="tv"]').onclick=()=>this.callbacks.onGadget?.('tv',this.roomId||this.department||'assembly');
    nav.querySelectorAll('[data-floor]').forEach(b=>b.onclick=()=>this.travelSelectedToFloor(Number(b.dataset.floor),nav.querySelector('select').value||undefined));
    nav.querySelector('[data-action="party-time"]').onclick=()=>this.partyAll?this.setPartyEnabled(false):this.startPartyTime();
    nav.querySelector('[data-action="party-end"]').onclick=()=>this.setPartyEnabled(false);
    nav.querySelector('[data-action="party"]').onclick=()=>this.setPartyEnabled(!this.partyEnabled);
    nav.querySelector('[data-action="music"]').onclick=()=>this.toggleDiscoMusic();
    this.host.before(nav);this.spaceControls=nav;this.syncSpaceControls();
  }
  syncSpaceControls(){
    if(!this.spaceControls)return;
    const selected=this.person(this.selected),state=this.elevators.getState(),ride=selected?.ride&&this.elevators.getRide(selected.data.id);
    this.spaceControls.querySelector('.world-lift-person').textContent=selected?.data.person.split(' ·')[0]||'Selecciona una persona';
    this.spaceControls.querySelectorAll('[data-room]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.room===(this.executiveView?'chiefs':this.roomId||(this.elevatorView?'elevators':this.department)))));
    this.spaceControls.querySelectorAll('[data-floor]').forEach(b=>{b.disabled=!selected;b.setAttribute('aria-pressed',String(Boolean(selected&&!ride&&Math.abs(selected.root.position.y-Number(b.dataset.floor))<.12)));});
    const phases={idle:'libre',positioning:'recogiendo',openingPickup:'abriendo',boarding:'abordando',closingPickup:'cerrando',moving:'en viaje',openingDropoff:'abriendo',alighting:'llegando',closingDropoff:'cerrando'};
    const text=(this.paused?'Movimiento pausado. ':'')+state.map(c=>`${c.name}: ${phases[c.phase]}${c.queue.length?` · ${c.queue.length} en espera`:''}`).join(' / ');
    const output=this.spaceControls.querySelector('.world-lift-status');if(output.textContent!==text)output.textContent=text;
    const panel=this.spaceControls.querySelector('.world-disco-controls');panel.hidden=this.roomId!=='disco';
    const people=[...this.agents,this.manager],dancing=people.filter(a=>a.mode==='dancing').length,travelling=people.filter(a=>a.mode!=='dancing'&&(a.arriveMode==='dancing'&&a.path.length||a.pendingDestination?.mode==='dancing')).length;
    const count=this.paused?'Movimiento pausado':this.partyAll?`${dancing} / ${people.length} bailando${travelling?` · ${travelling} llegando`:''}`:`${dancing} en la pista${travelling?` · ${travelling} subiendo`:''} · ${this.agents.filter(a=>a.workAssigned).length} con tareas`;
    this.spaceControls.querySelector('[data-action="party-time"]').setAttribute('aria-pressed',String(Boolean(this.partyAll)));
    panel.querySelector('[data-action="party-end"]').hidden=!this.partyAll;panel.classList.toggle('is-party-time',Boolean(this.partyAll));
    panel.querySelector('.world-disco-explainer').textContent=this.partyAll?'Todo el equipo y la gerencia a la pista. Las tareas reales siguen ejecutándose.':'Bailan los agentes libres. Las tareas tienen prioridad.';
    const counter=panel.querySelector('.world-disco-count');if(counter.textContent!==count)counter.textContent=count;
    const party=panel.querySelector('[data-action="party"]');party.textContent=this.partyEnabled?'Fiesta automática: activa':'Fiesta automática: apagada';party.setAttribute('aria-pressed',String(this.partyEnabled));party.hidden=Boolean(this.partyAll);
    const music=panel.querySelector('[data-action="music"]');music.textContent=this.discoAudio.enabled?'Apagar música':'Encender música';music.setAttribute('aria-pressed',String(this.discoAudio.enabled));music.disabled=this.paused||!this.partyEnabled;
  }
  person(id){return id==='company-manager'?this.manager:this.agents.find(a=>a.data.id===id);}
  addAgent(data,index){
    const f=figure(this.scene,data.color,index),home=HOMES[index];f.root.position.set(home.x,home.y,home.z);f.root.rotation.y=.3;
    const tag=document.createElement('button');tag.type='button';tag.className='world-tag';tag.innerHTML='<span></span><small></small>';tag.querySelector('span').textContent=data.person.split(' ·')[0];tag.onclick=()=>this.interact(data.id);this.labels.append(tag);
    const desk=document.createElement('button');desk.type='button';desk.className='desk-label';desk.innerHTML='<strong></strong><small></small>';desk.querySelector('strong').textContent=data.person.split(' ·')[0];desk.querySelector('small').textContent=data.name;desk.setAttribute('aria-label','Puesto de '+data.person+': '+data.name);desk.onclick=()=>this.interact(data.id);this.labels.append(desk);this.deskLabels.push({el:desk,index,department:data.department});
    const a={...f,data,index,home,path:[],mode:'idle',next:this.time+1.5+index*.8,phase:index*1.2,waveUntil:0,holdUntil:0,tag,status:'Disponible',task:null};this.agents.push(a);return a;
  }
  update(state,selected){
    if(!this.agents.length)state.agents.forEach((a,i)=>this.addAgent(a,i));
    const first=this.observedTasks.size===0;this.tasks=state.tasks;if(this.externalSelected===undefined)this.externalSelected=selected;else if(this.externalSelected!==selected){this.selected=selected;this.externalSelected=selected;}
    for(const a of this.agents){
      const running=this.syncAgentWork(a,state.tasks);
      a.tag.querySelector('small').textContent=a.status;a.tag.classList.toggle('is-working',Boolean(running));a.tag.classList.toggle('is-selected',selected===a.data.id);a.tag.setAttribute('aria-label',`${a.data.person}: ${a.data.name}. ${a.status}. Seleccionar`);
    }
    for(const t of state.tasks){
      if(!first&&this.observedTasks.get(t.id)!=='done'&&t.status==='done'){
        const a=this.agents.find(a=>a.data.id===t.agent),next=state.tasks.find(n=>n.contextIds?.includes(t.id)&&['running','queued'].includes(n.status));
        if(a){a.waveUntil=this.time+3;this.say(a,next?'Resultado listo. Se lo paso a '+this.agents.find(a=>a.data.id===next.agent)?.data.person.split(' ·')[0]+'.':'Terminé. Puedes revisar el resultado.',7);if(next)this.handoff(a,this.agents.find(a=>a.data.id===next.agent));}
      }
      this.observedTasks.set(t.id,t.status);
    }
    this.updateTVs?.(state);this.renderCard();this.updateRoster();this.syncSpaceControls();
  }
  syncAgentWork(a,tasks){
    const assigned=tasks.filter(t=>t.agent===a.data.id&&['running','queued','pending','error','interrupted'].includes(t.status));
    const running=assigned.find(t=>t.status==='running'),queued=assigned.some(t=>t.status==='queued'),pending=assigned.some(t=>t.status==='pending');
    const token=assigned.map(t=>t.id+':'+t.status).sort().join('|'),changed=token!==a.workToken;
    a.workAssigned=assigned.length>0;a.workStatus=running?'Trabajando':queued?'En cola':pending?'Tarea pendiente':assigned.length?'Revisar tarea':'Disponible';a.status=a.workStatus;
    const previous=a.task;a.task=running||null;
    if(changed&&a.workAssigned&&!this.partyAll){this.go(a,a.home,running?'working':'idle');a.holdUntil=0;if(running&&previous?.id!==running.id)this.say(a,'Voy con esta tarea: '+running.title,6);}
    if(changed&&!a.workAssigned&&a.workToken){a.next=this.time+2;a.holdUntil=0;if(a.mode==='working')a.mode='idle';}
    a.workToken=token;return running;
  }
  startPartyTime(){
    this.partyAll=true;this.partyEnabled=true;this.meetingUntil=0;
    if(this.paused)this.setPaused(false);this.focusRoom('disco');
    [...this.agents,this.manager].forEach((a,i)=>{this.go(a,a===this.manager?DISCO_MANAGER_SPOT:DISCO_SPOTS[i],'dancing');a.holdUntil=Infinity;});
    this.discoAudio?.start?.().catch(()=>this.callbacks.onNotice?.('La fiesta empezó. Puedes encender la música desde su botón.'));
    this.syncSpaceControls();this.callbacks.onNotice?.('¡Party Time! Todo el equipo y la gerencia van a la discoteca. Las tareas reales siguen ejecutándose.');
  }
  setPartyEnabled(enabled){
    this.partyAll=false;this.partyEnabled=Boolean(enabled);
    for(const a of [...this.agents,this.manager]){
      if(!enabled&&(a.mode==='dancing'||a.arriveMode==='dancing'&&a.path.length||a.pendingDestination?.mode==='dancing')){this.go(a,a.home,a.task?'working':'idle');a.holdUntil=a===this.manager?Infinity:this.time+4;}
      else if(enabled&&a!==this.manager&&!a.workAssigned&&!['meeting','break'].includes(a.mode)){a.holdUntil=0;a.next=this.time+a.index*.12;}
    }
    if(!enabled)this.discoAudio.stop();this.syncSpaceControls();
  }
  leavePartyTime(){if(this.partyAll){this.partyAll=false;this.discoAudio?.stop();}}
  async toggleDiscoMusic(){
    try{if(this.discoAudio.enabled)await this.discoAudio.stop();else await this.discoAudio.start();}
    catch{this.callbacks.onNotice?.('No se pudo encender el sonido. Puedes volver a intentarlo.');}
    this.syncSpaceControls();
  }
  updateRoster(){
    const roster=document.getElementById('world-roster');if(!roster)return;const management=this.department==='management';roster.hidden=management;document.getElementById('management-panel').hidden=!management;document.getElementById('world-gather').textContent=management?'Reunir a los jefes':'Reunir al equipo';
    if(!roster.children.length){
      for(const d of WINGS){const section=document.createElement('section');section.className='department-team';section.dataset.department=d.id;const header=document.createElement('h3');header.textContent=d.name+' · '+d.count;header.style.color=d.color;section.append(header);
        this.agents.filter(a=>a.data.department===d.id).forEach(a=>{const b=document.createElement('button');b.type='button';b.className='roster-agent';b.dataset.id=a.data.id;b.innerHTML='<span class="roster-dot"></span><span><strong></strong><small></small><p></p></span>';b.querySelector('strong').textContent=a.data.person.split(' ·')[0];b.querySelector('.roster-dot').style.background=a.data.color;b.querySelector('p').textContent=a.data.job;b.onclick=()=>this.interact(a.data.id);section.append(b);});roster.append(section);
      }
    }
    roster.classList.toggle('department-focused',Boolean(this.department));
    roster.querySelectorAll('[data-department]').forEach(s=>s.hidden=Boolean(this.department&&s.dataset.department!==this.department));
    this.agents.forEach(a=>{const b=roster.querySelector(`[data-id="${a.data.id}"]`);b.classList.toggle('selected',this.selected===a.data.id);b.setAttribute('aria-pressed',String(this.selected===a.data.id));b.setAttribute('aria-label',`Seleccionar a ${a.data.person.split(' ·')[0]}, ${a.data.name}`);b.querySelector('small').textContent=a.data.name+' · '+a.status;});
    const tabs=document.getElementById('department-tabs');
    if(tabs&&!tabs.children.length){const all=document.createElement('button');all.type='button';all.dataset.wing='';all.textContent='Toda la oficina · '+this.staff.length;all.onclick=()=>this.cameraHome();tabs.append(all);const owner=document.createElement('button');owner.type='button';owner.dataset.wing='management';owner.className='owner-room-tab';owner.textContent='Mi oficina · la gerencia';owner.onclick=()=>this.focusDepartment('management');tabs.append(owner);for(const d of WINGS){const b=document.createElement('button');b.type='button';b.dataset.wing=d.id;b.textContent=d.compact?d.name:d.name+' · '+d.count;b.style.setProperty('--wing-color',d.color);b.onclick=()=>this.focusDepartment(d.id);tabs.append(b);}}
    const heads=document.getElementById('management-chiefs');if(heads&&!heads.children.length)this.agents.filter(a=>CHIEF_IDS.includes(a.data.id)).forEach(a=>{const b=document.createElement('button');b.type='button';b.innerHTML='<i></i><span><strong></strong><small></small></span>';b.querySelector('i').style.background=a.data.color;b.querySelector('strong').textContent=a.data.person;b.querySelector('small').textContent=a.data.name;b.onclick=()=>this.interact(a.data.id);heads.append(b);});
    document.getElementById('office-wing-title').textContent=this.executiveView?'Sala de jefes · Dirección':this.roomId==='assembly'?'Zona común · Sala de equipo':this.roomId?COMMON_ROOMS[this.roomId].name:this.elevatorView?'Ascensores · '+ELEVATOR_FLOORS.length+' pisos':management?'Gerencia general · Tu empresa':this.department?`${WINGS.find(d=>d.id===this.department).compact?'Puesto de':'Ala de'} ${WINGS.find(d=>d.id===this.department).name} · Piso ${WINGS.find(d=>d.id===this.department).y/6+1}`:'Tu oficina · 5 pisos · 6 departamentos y Gerencia';
    tabs?.querySelectorAll('button').forEach(b=>{b.classList.toggle('active',b.dataset.wing===(this.department||''));b.setAttribute('aria-pressed',String(b.dataset.wing===(this.department||'')));});
  }
  focusDepartment(id){if(id!=='management'&&!WINGS.some(d=>d.id===id))return;this.department=id;this.roomId=null;this.executiveView=false;this.elevatorView=false;this.followId=null;this.pan={x:0,z:0};this.azimuth=id==='management'?-.16:.16;this.elevation=.45;this.zoom=1;this.card.hidden=true;this.speech.hidden=true;this.setFloorVisibility();this.resize();this.updateRoster();this.syncSpaceControls();this.callbacks.onContext?.(id);}
  focusRoom(id){if(id==='chiefs'){this.focusChiefs();return;}if(!COMMON_ROOMS[id])return;this.roomId=id;this.department=null;this.executiveView=false;this.elevatorView=false;this.followId=null;this.pan={x:0,z:0};this.azimuth=id==='canteen'?-.12:.12;this.elevation=id==='disco'?.65:.48;this.zoom=1;this.card.hidden=true;this.speech.hidden=true;this.setFloorVisibility();this.resize();this.updateRoster();this.syncSpaceControls();this.callbacks.onContext?.(id);}
  focusChiefs(){this.department='management';this.roomId=null;this.executiveView=true;this.elevatorView=false;this.followId=null;this.pan={x:0,z:0};this.azimuth=-.14;this.elevation=.6;this.zoom=1;this.card.hidden=true;this.speech.hidden=true;this.setFloorVisibility();this.resize();this.updateRoster();this.syncSpaceControls();this.callbacks.onContext?.('management');}
  focusElevators(){this.roomId=null;this.department=null;this.executiveView=false;this.elevatorView=true;this.followId=null;this.pan={x:0,z:0};this.azimuth=.12;this.elevation=.2;this.zoom=1;this.card.hidden=true;this.setFloorVisibility();this.resize();this.updateRoster();this.syncSpaceControls();this.callbacks.onContext?.('elevators');}
  renderCard(){const a=this.person(this.selected);if(!a)return;const owner=a===this.manager;this.card.querySelector('.world-card-kicker').textContent=owner?'GERENCIA GENERAL / TU OFICINA':a.data.departmentName+' / '+a.data.name+' / '+a.status;this.card.querySelector('strong').textContent=a.data.person;this.card.querySelector('p').textContent=a.task?.title||a.data.job;this.card.querySelector('.world-assign').textContent=owner?'Revisar entregas →':'Asignar tarea →';this.card.querySelector('.world-result').textContent=owner?'Reunir jefes':'Ver último resultado';this.card.querySelector('.world-result').hidden=!owner&&!this.tasks.some(t=>t.agent===a.data.id&&t.result);}
  select(id){if(!this.person(id))return;this.selected=id;[...this.agents,this.manager].forEach(a=>a.tag.classList.toggle('is-selected',a.data.id===id));this.renderCard();this.updateRoster();this.syncSpaceControls();}
  interact(id){const a=this.person(id);if(!a)return;const room=this.roomAt(a.root.position);if(a.ride)this.focusElevators();else if(room)this.focusRoom(room.id);else this.focusDepartment(this.departmentAt(a.root.position)?.id||a.data.department);this.select(id);if(a!==this.manager)this.callbacks.onSelect?.(id);this.card.hidden=false;if(!a.task&&!a.ride&&!a.path.length&&!['meeting','break','dancing'].includes(a.mode)){a.mode='idle';a.root.rotation.y=this.azimuth;}this.followId=id;this.zoom=this.width<600?1.15:1.5;this.resize();this.host.scrollIntoView({block:'center',behavior:this.reduced.matches?'instant':'smooth'});a.waveUntil=this.time+3.2;if(!['meeting','break','dancing'].includes(a.mode))a.holdUntil=this.time+5;this.say(a,a===this.manager?'Gerencia. Puedes moverme, reunir al equipo o revisar sus entregas.':a.task?'Estoy trabajando en: '+a.task.title:'Soy '+a.data.person+', '+a.data.name.toLocaleLowerCase()+'. ¿Qué necesitas?',5);}

  say(a,text,seconds=4){this.speech.textContent=text;this.speech.hidden=false;this.speaker=a;this.speechUntil=this.time+seconds;}
  go(a,target,mode='walk',options={}){
    if(a.ride){
      const ride=this.elevators.getRide(a.data.id);
      if(ride?.status==='arrived'){a.root.position.set(ride.position.x,ride.position.y,ride.position.z);a.ride=null;}
      else if(!this.elevators.cancelRide(a.data.id)){a.pendingDestination={target:{...target},mode,options:{...options}};return true;}
      else a.ride=null;
    }
    const route=findPath(a.root.position,target,options);if(!route.length)return false;
    a.pendingDestination=null;a.path=route;a.arriveMode=mode;a.arrivalFacing=target.facing;a.mode='walk';a.next=this.time+4+Math.random()*4;return true;
  }
  moveSelected(point){const a=this.person(this.selected);if(!a)return;
    if(a.task){this.say(a,'Estoy con una tarea. En cuanto termine puedo moverme.',4);return;}
    if(!walkable(point.x,point.z,point.y)){this.callbacks.onNotice('Toca un espacio libre del suelo.');return;}
    if(this.go(a,point)){a.holdUntil=this.time+10;this.say(a,this.paused?'Iré cuando reanudes el movimiento.':a.pendingDestination?'Voy al terminar este viaje.':'¡Voy para allá!',3);this.destination.position.set(point.x,point.y+.12,point.z);this.destination.visible=true;this.destinationUntil=this.time+5;}
  }
  travelSelectedToFloor(y,elevatorId){
    const a=this.person(this.selected);if(!a||!ELEVATOR_FLOORS.includes(y))return false;
    const target={x:a.root.position.x<0?-3:3,y,z:6.8};
    if(!this.go(a,target,a.task?'working':'idle',{elevatorId}))return false;
    a.holdUntil=Infinity;this.focusElevators();this.say(a,this.paused?'El viaje está preparado. Pulsa Reanudar movimiento.':`Voy al piso ${y/6+1}${a.pendingDestination?' después de este viaje':''}.`,5);this.syncSpaceControls();return true;
  }
  gather(){
    if(this.department==='management'){this.gatherChiefs();return;}
    this.gatherAll();
  }
  gatherAll(){this.leavePartyTime();this.focusRoom('assembly');this.meetingUntil=Infinity;[...this.agents,this.manager].forEach((a,i)=>{a.meetingLook={x:29,y:0,z:0};this.go(a,ASSEMBLY_SEATS[i],'meeting');a.holdUntil=Infinity;});this.say(this.manager,'¡Equipo, nos vemos en la sala de todos!',5);this.callbacks.onNotice?.('El equipo se reúne en este espacio. La reunión visual no inicia ni detiene tareas.');}
  takeBreak(){this.leavePartyTime();this.focusRoom('canteen');this.meetingUntil=Infinity;[...this.agents,this.manager].forEach((a,i)=>{this.go(a,CANTEEN_SEATS[i],'break');a.holdUntil=Infinity;});this.say(this.manager,'Hagamos una pausa en el comedor.',5);this.callbacks.onNotice?.('El equipo y La gerencia va al comedor. Las tareas reales conservan su estado.');}
  gatherChiefs(){this.leavePartyTime();const heads=this.agents.filter(a=>CHIEF_IDS.includes(a.data.id));this.focusChiefs();this.meetingUntil=Infinity;heads.forEach((a,i)=>{a.meetingLook={x:14,y:MANAGEMENT.y,z:2.5};this.go(a,EXEC_MEETING[i],'meeting');a.holdUntil=Infinity;});this.manager.meetingLook={x:14,y:MANAGEMENT.y,z:2.5};this.go(this.manager,MANAGER_MEETING,'meeting');this.manager.holdUntil=Infinity;this.manager.waveUntil=this.time+3;this.callbacks.onNotice?.('Gerencia y los jefes van a la sala de dirección. Esta reunión visual no inicia ni detiene tareas.');}
  home(){this.leavePartyTime();this.meetingUntil=0;[...this.agents,this.manager].forEach(a=>{this.go(a,a.home,a.task?'working':'idle');a.holdUntil=this.time+7;});}
  handoff(from,to){if(!to||from===to)return;const mesh=box(this.scene,from.root.position.x,2,from.root.position.z,.43,.3,.08,'#ffe08a');this.packets.push({mesh,from:from.root.position.clone(),to,start:this.time,duration:2});}
  setPaused(value){this.paused=Boolean(value);if(value)this.discoAudio?.pause();else if(this.discoAudio?.enabled&&this.partyEnabled)this.discoAudio.start().catch(()=>{});const b=document.getElementById('world-pause');if(b){b.textContent=value?'Reanudar movimiento':'Pausar movimiento';b.setAttribute('aria-pressed',String(value));}this.syncSpaceControls();}
  cameraHome(){this.followId=null;this.department=null;this.roomId=null;this.executiveView=false;this.elevatorView=false;this.pan={x:0,z:0};this.azimuth=.25;this.elevation=.24;this.zoom=1;this.card.hidden=true;this.speech.hidden=true;this.setFloorVisibility();this.resize();this.updateRoster();this.syncSpaceControls();this.callbacks.onContext?.(null);}
  resize(){const w=this.host.clientWidth,h=this.host.clientHeight;if(!w||!h)return;this.width=w;this.height=h;this.renderer.setSize(w,h,false);const aspect=w/h,vertical=this.followId?4.2:this.executiveView?4.1:this.roomId?7.8:this.elevatorView?16:this.department==='management'?8.4:this.department==='operations-wing'?4.7:this.department?6.4:21,horizontal=this.followId?5:this.executiveView?5.4:this.roomId?9:this.elevatorView?6:this.department==='management'?22:this.department==='operations-wing'?6:this.department?10:44,span=Math.max(vertical,horizontal/aspect)/this.zoom;Object.assign(this.camera,{left:-span*aspect,right:span*aspect,top:span,bottom:-span});this.camera.updateProjectionMatrix();this.cameraPosition();}
  cameraBase(){return this.person(this.followId)?.root.position||(this.executiveView?{x:14,y:MANAGEMENT.y,z:2.5}:null)||(this.roomId?COMMON_ROOMS[this.roomId]:null)||(this.elevatorView?{x:0,y:MANAGEMENT.y/2+2,z:5.6}:null)||(this.department==='management'?{x:0,y:MANAGEMENT.y,z:0}:WINGS.find(d=>d.id===this.department))||{x:0,y:MANAGEMENT.y/2+2,z:2};}
  departmentAt(p){return WINGS.find(d=>d.compact&&Math.abs(d.y-p.y)<.3&&Math.abs(d.x-p.x)<2&&Math.abs(d.z+1-p.z)<2)||[...WINGS.filter(d=>!d.compact),MANAGEMENT].find(d=>Math.abs(d.y-p.y)<.3&&Math.abs(d.x-p.x)<8.5);}
  roomAt(p){return Object.values(COMMON_ROOMS).find(r=>Math.abs(p.y-r.y)<.3&&Math.abs(p.x-r.x)<r.width/2&&Math.abs(p.z-r.z)<r.depth/2);}
  setFloorVisibility(){const d=this.roomId?COMMON_ROOMS[this.roomId]:this.department==='management'?MANAGEMENT:WINGS.find(d=>d.id===this.department);this.activeFloor=d?.y??null;this.floors.forEach((f,i)=>f.visible=!d||i*6<=d.y);this.roofs.forEach(r=>r.visible=!d&&!this.elevatorView);for(const f of this.floors)for(const c of f.children)if(c.userData.ceiling)c.visible=!d&&!this.elevatorView;this.extraRooms?.forEach(r=>r.group.visible=(!d||r.y<=d.y)&&(!this.roomId||r.id===this.roomId));this.elevators?.setVisibleFloor?.(this.activeFloor);}
  cameraPosition(){const r=80,b=this.cameraBase(),p={x:b.x+this.pan.x,y:(b.y||0)+((this.department||this.roomId)?1.6:0),z:b.z+this.pan.z};this.cameraTarget=new THREE.Vector3(p.x,p.y,p.z);this.cameraGoal=new THREE.Vector3(p.x+Math.sin(this.azimuth)*r*Math.cos(this.elevation),p.y+Math.sin(this.elevation)*r,p.z+Math.cos(this.azimuth)*r*Math.cos(this.elevation));if(!this.cameraLook){this.cameraLook=this.cameraTarget.clone();this.camera.position.copy(this.cameraGoal);this.camera.lookAt(this.cameraLook);}const zoom=document.getElementById('world-zoom-value');if(zoom)zoom.textContent=Math.round(this.zoom*100)+'%';}
  panView(horizontal,vertical){const step=(this.camera.top-this.camera.bottom)*.035;this.pan.x=THREE.MathUtils.clamp(this.pan.x+(horizontal*Math.cos(this.azimuth)-vertical*Math.sin(this.azimuth))*step,-45,45);this.pan.z=THREE.MathUtils.clamp(this.pan.z+(-horizontal*Math.sin(this.azimuth)-vertical*Math.cos(this.azimuth))*step,-45,45);this.cameraPosition();}
  zoomBy(delta){this.zoom=THREE.MathUtils.clamp(this.zoom+delta,.65,4);this.resize();}
  handleNavigationKey(e){if(e.ctrlKey||e.metaKey||e.altKey)return;const directions={ArrowLeft:[-1,0],ArrowRight:[1,0],ArrowUp:[0,1],ArrowDown:[0,-1]};if(directions[e.key]){e.preventDefault();this.panView(...directions[e.key]);}else if(['+','=','-'].includes(e.key)){e.preventDefault();this.zoomBy(e.key==='-'?-.15:.15);}else if(e.key==='Home'){e.preventDefault();this.cameraHome();}else if(e.key==='Escape')this.card.hidden=true;}
  pointerEvents(){
    const c=this.canvas;let down=null;
    c.addEventListener('pointerdown',e=>{c.focus({preventScroll:true});down={x:e.clientX,y:e.clientY,ox:e.clientX,oy:e.clientY,moved:false};c.setPointerCapture(e.pointerId);});
    c.addEventListener('pointermove',e=>{if(!down)return;const dx=e.clientX-down.x,dy=e.clientY-down.y;if(Math.hypot(e.clientX-down.ox,e.clientY-down.oy)>5)down.moved=true;if(down.moved){this.azimuth-=dx*.006;this.elevation=THREE.MathUtils.clamp(this.elevation+dy*.004,.08,1.2);this.cameraPosition();}down.x=e.clientX;down.y=e.clientY;});
    c.addEventListener('pointerup',e=>{if(!down)return;const click=!down.moved;down=null;if(!click)return;const b=c.getBoundingClientRect();this.pointer.set((e.clientX-b.left)/b.width*2-1,-(e.clientY-b.top)/b.height*2+1);this.pickAt(this.pointer);});
    c.addEventListener('pointercancel',()=>down=null);
    c.addEventListener('wheel',e=>{e.preventDefault();const delta=e.deltaY*(e.deltaMode===1?16:1);this.zoomBy(-Math.sign(delta)*Math.min(.22,Math.max(.035,Math.abs(delta)*.0018)));},{passive:false});
    c.addEventListener('keydown',e=>{this.handleNavigationKey(e);if(e.defaultPrevented)e.stopPropagation();});
  }
  pickAt(pointer){
    this.ray.setFromCamera(pointer,this.camera);const people=[...this.agents,this.manager];
    const visible=o=>{for(let p=o;p;p=p.parent)if(!p.visible)return false;return true;};
    const hits=this.ray.intersectObjects([...people.map(a=>a.root),...(this.gadgetMeshes||[])].filter(visible),true).filter(h=>visible(h.object));
    const hit=hits[0];if(hit){const gadget=hit.object.userData.gadget;if(gadget){this.callbacks.onGadget?.(gadget.tool,gadget.context);return;}const a=people[hit.object.userData.agentIndex];if(a){this.interact(a.data.id);return;}}
    const floorHit=this.ray.intersectObjects(this.pickFloors.filter(visible),true)[0];
    if(floorHit){let parent=floorHit.object;while(parent&&parent.userData.floor===undefined)parent=parent.parent;const point=floorHit.point.clone();point.y=parent?.userData.floor??0;this.moveSelected(point);return;}
    const point=new THREE.Vector3();this.ground.constant=0;if(this.ray.ray.intersectPlane(this.ground,point)&&this.roomAt(point))this.moveSelected(point);
  }
  tickAgent(a,dt,{instant=this.reduced.matches}={}){
    const t=this.time,p=a.root.position;let walking=false,transport=false;
    if(a.path.length){
      let remaining=instant?Infinity:2.3*dt,guard=0;
      while(a.path.length&&guard++<2048){
        const v=a.path[0];
        if(v.type==='elevator'){
          if(!a.ride)a.ride=this.elevators.requestRide({riderId:a.data.id,fromY:v.fromY,toY:v.toY,elevatorId:v.elevatorId});
          if(instant)this.elevators.update(0);
          const ride=this.elevators.getRide(a.data.id);a.mode='elevator';transport=true;
          if(ride.position)p.set(ride.position.x,ride.position.y,ride.position.z);
          a.root.rotation.y=ride.status==='boarding'?Math.PI:0;
          if(ride.status!=='arrived')break;
          a.ride=null;a.path.shift();transport=false;
          if(a.pendingDestination){const next=a.pendingDestination;a.pendingDestination=null;this.go(a,next.target,next.mode,next.options);}
          continue;
        }
        // Floor changes are exclusively owned by the elevator controller.
        if(Math.abs((v.y??p.y)-p.y)>.12){a.path=[];a.mode='idle';this.callbacks.onNotice?.('No se pudo completar ese recorrido. Selecciona de nuevo el piso.');break;}
        const dx=v.x-p.x,dz=v.z-p.z,d=Math.hypot(dx,dz);
        if(d>.025){const desired=Math.atan2(dx,dz),diff=Math.atan2(Math.sin(desired-a.root.rotation.y),Math.cos(desired-a.root.rotation.y));a.root.rotation.y+=diff*(instant?1:Math.min(1,dt*12));}
        if(d<=remaining+1e-8){p.set(v.x,v.y??p.y,v.z);a.path.shift();remaining-=d;walking=walking||d>.025;}else if(remaining>0){p.x+=dx/d*remaining;p.z+=dz/d*remaining;walking=true;remaining=0;}
        if(remaining<=1e-8&&!instant)break;
      }
      if(!a.path.length){a.mode=a.arriveMode||'idle';a.next=t+4+Math.random()*5;walking=false;}
    }else if(['meeting','break'].includes(a.mode)&&this.meetingUntil>t){
      a.root.rotation.y=a.arrivalFacing??Math.atan2((a.meetingLook?.x??p.x)-p.x,(a.meetingLook?.z??p.z)-p.z);if(!instant&&Math.sin(t*.7+a.index)>.98)a.waveUntil=t+.8;
    }else if(this.partyAll&&a.mode!=='dancing'&&t>a.next){
      if(!this.go(a,a===this.manager?DISCO_MANAGER_SPOT:DISCO_SPOTS[a.index],'dancing'))a.next=t+1;
    }else if(a.task&&!(this.partyAll&&a.mode==='dancing')){a.mode='working';a.root.rotation.y=a.home.facing;}
    else if(a.mode==='dancing'){a.root.rotation.y=a.arrivalFacing??0;}
    else if(this.partyEnabled&&!a.workAssigned&&a!==this.manager&&t>a.next&&t>a.holdUntil&&!(this.followId===a.data.id&&!this.card.hidden)){
      if(!this.go(a,DISCO_SPOTS[a.index],'dancing'))a.next=t+10;
    }
    const seated=!a.path.length&&['meeting','break'].includes(a.mode),stride=Math.sin(t*10+a.phase),wave=!instant&&!transport&&a.waveUntil>t;
    a.legs[0].rotation.x=seated?-Math.PI/2:walking&&!instant?stride*.62:0;a.legs[1].rotation.x=seated?-Math.PI/2:walking&&!instant?-stride*.62:0;
    a.arms.forEach((arm,i)=>{const side=i?1:-1;arm.position.x=side*(transport?.38:.45);arm.rotation.x=transport?-.5:instant?0:walking?(i?-stride:stride)*.6:a.mode==='working'?-1.15+Math.sin(t*13+i*2)*.12:Math.sin(t*1.5+a.phase+i)*.06;arm.rotation.z=side*(transport?-.32:.11);});
    const dancing=a.mode==='dancing'&&!walking&&!transport;
    if(wave&&!dancing){a.arms[1].rotation.z=-2.5+Math.sin(t*12)*.35;a.arms[1].rotation.x=-.25;}
    a.body.position.y=seated?.05:instant||transport?0:walking?Math.abs(stride)*.055:Math.sin(t*2+a.phase)*.012;
    a.head.rotation.y=instant||transport?0:a.mode==='working'?Math.sin(t*.9)*.08:Math.sin(t*.7+a.phase)*.19;
    a.body.rotation.z=dancing&&!instant?Math.sin(t*3.7+a.phase)*.14:0;
    a.body.rotation.y=dancing&&!instant?Math.sin(t*1.85+a.phase)*.15:0;
    if(dancing){
      a.body.position.y=instant?0:.04+Math.abs(Math.sin(t*3.7+a.phase))*.13;
      a.legs.forEach((leg,i)=>leg.rotation.x=instant?0:Math.sin(t*3.7+a.phase+i*Math.PI)*.26);
      a.arms.forEach((arm,i)=>{const side=i?1:-1;arm.rotation.z=side*(a.index%3===0?1.5:1)+(instant?0:Math.sin(t*1.85+a.phase+i)*.6);arm.rotation.x=instant?-.25:-.5+Math.sin(t*3.7+a.phase+i)*.4;});
    }
    if(a.tag&&a!==this.manager){const status=this.partyAll&&dancing?(a.workAssigned?a.workStatus+' · En la fiesta':'Party Time · Bailando'):a.workAssigned?a.workStatus:dancing?'Libre · Bailando':a.arriveMode==='dancing'&&a.path.length?'Libre · Subiendo al club':a.workStatus||'Disponible';if(a.status!==status){a.status=status;a.tag.querySelector('small').textContent=status;a.tag.setAttribute('aria-label',`${a.data.person}: ${a.data.name}. ${status}. Seleccionar`);}}
    if(this.screens[a.index])this.screens[a.index].emissiveIntensity=a.task ? .4+(instant?0:Math.sin(t*5)*.1) : .12;
  }
  separate(dt){
    const people=[...this.agents,this.manager];
    for(let i=0;i<people.length;i++)for(let j=i+1;j<people.length;j++){
      const a=people[i],b=people[j],p=a.root.position,q=b.root.position;
      if(a.ride||b.ride||['meeting','break'].includes(a.mode)||['meeting','break'].includes(b.mode))continue;
      let dx=p.x-q.x,dz=p.z-q.z,d=Math.hypot(dx,dz);if(d>=.8||Math.abs(p.y-q.y)>.4)continue;
      if(d<.001){dx=Math.cos(i+j);dz=Math.sin(i+j);d=1;}
      const push=Math.min(.055,dt*1.6),nx=dx/d*push,nz=dz/d*push;
      if(!a.task&&a.path.length&&walkable(p.x+nx,p.z+nz,p.y)){p.x+=nx;p.z+=nz;}
      if(!b.task&&b.path.length&&walkable(q.x-nx,q.z-nz,q.y)){q.x-=nx;q.z-=nz;}
    }
  }
  advanceSimulation(dt){
    if(this.paused)return false;
    this.time+=dt;this.elevators.update(this.reduced.matches?0:dt);
    [...this.agents,this.manager].forEach(a=>this.tickAgent(a,this.reduced.matches?0:dt));
    if(!this.reduced.matches)this.separate(dt);this.elevators.drainEvents();
    for(const packet of [...this.packets]){const f=this.reduced.matches?1:Math.min(1,(this.time-packet.start)/packet.duration);packet.mesh.position.lerpVectors(packet.from,packet.to.root.position,f);packet.mesh.position.y+=2+Math.sin(f*Math.PI)*2;packet.mesh.rotation.y=this.time*2;if(f===1){this.scene.remove(packet.mesh);this.packets.splice(this.packets.indexOf(packet),1);}}
    return true;
  }
  frame(ms){
    if(ms-this.last<1000/24){this.raf=requestAnimationFrame(t=>this.frame(t));return;}
    const dt=Math.min((ms-(this.last||ms))/1000,.08);this.last=ms;
    if(this.visible&&!document.hidden){
      this.advanceSimulation(dt);
      this.updateScreens?.(dt,this.time,{reducedMotion:this.reduced.matches,paused:this.paused});
      this.disco?.update(this.time,{reducedMotion:this.reduced.matches,paused:this.paused,enabled:this.partyEnabled,partyAll:this.partyAll});
      this.syncSpaceControls();
      const selected=this.person(this.selected);if(selected)this.selection.position.set(selected.root.position.x,selected.root.position.y+.13,selected.root.position.z);
      if(this.followId)this.cameraPosition();
      if(this.destination.visible&&this.time>this.destinationUntil)this.destination.visible=false;
      for(const a of [...this.agents,this.manager])a.root.visible=this.activeFloor===null||this.activeFloor===undefined||a.root.position.y<=this.activeFloor+.3;
      const point=new THREE.Vector3();for(const a of [...this.agents,this.manager]){point.copy(a.root.position);point.y+=2.7;point.project(this.camera);const x=(point.x*.5+.5)*this.width,y=(-point.y*.5+.5)*this.height;a.tag.style.transform=`translate(${x}px,${y}px) translate(-50%,-100%)`;a.tag.hidden=!a.root.visible||x<0||x>this.width||y<0||y>this.height||Boolean(this.followId&&this.followId!==a.data.id)||Boolean(this.roomId&&this.roomAt(a.root.position)?.id!==this.roomId)||Boolean(this.roomId==='disco'&&a.data.id!==this.selected)||Boolean(this.department&&(this.department==='management'?this.departmentAt(a.root.position)?.id!=='management':a.data.department!==this.department))||Boolean(this.elevatorView&&a.data.id!==this.selected)||(!this.department&&!this.roomId&&!this.followId&&!this.elevatorView)||(!this.roomId&&!a.task&&a.data.id!==this.selected&&Math.hypot(a.root.position.x-a.home.x,a.root.position.z-a.home.z)<2);}
      for(const d of this.deskLabels){point.set(DESKS[d.index][0],DESKS[d.index][2]+2.6,DESKS[d.index][1]);point.project(this.camera);d.el.style.transform=`translate(${(point.x*.5+.5)*this.width}px,${(-point.y*.5+.5)*this.height}px) translate(-50%,-100%)`;d.el.hidden=(d.department!==this.department&&!(this.department==='product-wing'&&d.department==='operations-wing'))||Boolean(this.followId);}
      point.set(10,MANAGEMENT.y+1.5,-1.4);point.project(this.camera);this.managerDeskLabel.style.transform=`translate(${(point.x*.5+.5)*this.width}px,${(-point.y*.5+.5)*this.height}px) translate(-50%,-100%)`;this.managerDeskLabel.hidden=this.department!=='management'||Boolean(this.followId);
      for(const w of this.wingLabels){point.set(w.x,w.y,w.z);point.project(this.camera);w.el.style.transform=`translate(${(point.x*.5+.5)*this.width}px,${(-point.y*.5+.5)*this.height}px) translate(-50%,-100%)`;w.el.hidden=Boolean(this.department||this.roomId||this.elevatorView||this.followId);}
      for(const s of this.spaceLabels){point.set(s.x,s.y,s.z);point.project(this.camera);const x=(point.x*.5+.5)*this.width,y=(-point.y*.5+.5)*this.height;s.el.style.transform=`translate(${x}px,${y}px) translate(-50%,-100%)`;s.el.hidden=(s.id==='disco'&&this.roomId==='disco')||(s.id==='chiefs'&&this.department!=='management')||Boolean(this.followId||this.elevatorView)||x<0||x>this.width||y<0||y>this.height||Boolean(this.roomId&&s.id!==this.roomId)||Boolean(this.department&&(s.id!=='chiefs'||this.department!=='management'))||Boolean(this.executiveView);}
      if(this.speaker&&!this.speech.hidden){if(this.time>this.speechUntil)this.speech.hidden=true;else{point.copy(this.speaker.root.position);point.y+=3.7;point.project(this.camera);const x=THREE.MathUtils.clamp((point.x*.5+.5)*this.width,120,this.width-120),y=Math.max(15,(-point.y*.5+.5)*this.height);this.speech.style.left=x+'px';this.speech.style.top=y+'px';}}
      this.cameraPosition();
      const ease=this.reduced.matches?1:Math.min(1,dt*8);this.camera.position.lerp(this.cameraGoal,ease);this.cameraLook.lerp(this.cameraTarget,ease);this.camera.lookAt(this.cameraLook);
      this.renderer.render(this.scene,this.camera);
    }
    this.raf=requestAnimationFrame(t=>this.frame(t));
  }
}
