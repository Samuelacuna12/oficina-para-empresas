import * as THREE from './vendor/three.module.js';
import {WINGS,MANAGEMENT,COMMON_ROOMS,ASSEMBLY_SEATS,CANTEEN_SEATS,CANTEEN_TABLES} from './scene-path.js';

export function buildAmenities(room,floors,{box,cylinder,solid,group,labelTexture,chair,plant}){
 const dark='#263b3b',wood='#ad7950',stone='#d4c6ae',glass=new THREE.MeshStandardMaterial({color:'#a2c6ca',transparent:true,opacity:.13,roughness:.2,depthWrite:false});
 const gadgetMeshes=[],televisions=[],extraRooms=[];
 const clockFormat=new Intl.DateTimeFormat('es-CO',{timeZone:'America/Bogota',hour:'2-digit',minute:'2-digit',second:'2-digit',hourCycle:'h23'});
 const receivedFormat=new Intl.DateTimeFormat('es-CO',{timeZone:'America/Bogota',hour:'2-digit',minute:'2-digit',hourCycle:'h23'});
 const motionPreference=globalThis.matchMedia?.('(prefers-reduced-motion: reduce)');
 let screenTime=0,lastScreenPaint=-Infinity,lastClockSecond=-1,screenDirty=true,screenPaused=false,screenReduced=Boolean(motionPreference?.matches),screenConnected=null;
 function interactive(mesh,tool,context){mesh.userData.gadget={tool,context};gadgetMeshes.push(mesh);return mesh;}
 function tv(parent,x,y,z,context,w=5.4){
  const g=group(parent,x,y,z),height=w*.5;
  interactive(box(g,0,0,0,w,height,.14,'#101d22'),'tv',context);
  const canvas=document.createElement('canvas');canvas.width=1024;canvas.height=512;
  const texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;texture.generateMipmaps=false;texture.minFilter=THREE.LinearFilter;
  const panel=solid(g,new THREE.PlaneGeometry(w-.13,height-.13),new THREE.MeshBasicMaterial({map:texture,toneMapped:false}),0,0,.09);interactive(panel,'tv',context);
  cylinder(g,w/2-.14,-height/2+.055,.1,.025,.035,'#53d5a3',8).rotation.x=Math.PI/2;
  const department=[...WINGS,MANAGEMENT].find(d=>d.id===context);
  televisions.push({canvas,texture,context,root:g,panel,view:null,receivedAt:null,signature:'',cycleStart:0,tickerWidth:0,tickerText:'',accent:department?.color||'#73d8b0',title:department?.name|| (context==='canteen'?'Comedor · El equipo':'Sala de equipo')});
  return g;
 }
 const specs={marketing:['resources','RECURSOS'],sales:['prospects','CRM'],innovation:['assign','LAB'],finance:['calculator','MARGEN'],intelligence:['learning','PROCESOS'],management:['review','ENTREGAS']};
 for(const d of [...WINGS,MANAGEMENT]){
  const p=floors[d.y/6];
  if(d.compact){
   // Coordination shares the team floor; one live desk screen replaces an empty wing.
   tv(p,d.x,1.72,d.z-.32,d.id,1.45);
   const pad=solid(p,new THREE.PlaneGeometry(.52,.35),labelTexture('CRM','#15362f','#c7f4df'),d.x+1.15,1.38,d.z+.14);interactive(pad,'prospects',d.id);continue;
  }
  tv(p,d.x+2.7,2.65,-5.87,d.id,d.id==='management'?6.2:5.4);
  const board=solid(p,new THREE.PlaneGeometry(3.5,1.35),new THREE.MeshBasicMaterial({transparent:true,opacity:0,depthWrite:false}),d.x-4,2.1,-5.78);interactive(board,'notes',d.id);
  const [tool,title]=specs[d.id]||['prospects','OPERACIONES'],g=group(p,d.x-6.7,0,3.9);box(g,0,.65,0,.75,1.3,.65,dark);box(g,0,1.42,0,1.2,.1,.8,wood);box(g,0,1.77,-.15,1.2,.68,.09,dark);
  interactive(solid(g,new THREE.PlaneGeometry(1.08,.55),labelTexture(title,'#15362f','#c7f4df'),0,1.77,-.09),tool,d.id);for(let k=0;k<5;k++)box(g,-.38+k*.19,1.49,.15,.12,.02,.2,'#bacdc5');
 }
 for(const [id,r]of Object.entries(COMMON_ROOMS).filter(([,r])=>r.y===0)){
  const g=group(room,r.x,0,0);extraRooms.push({id,group:g,y:0});
  box(g,0,-.18,0,14.4,.36,13.8,stone);box(g,0,.025,0,13.9,.05,13.3,'#c1a07a');
  box(g,0,2.35,-6.7,14.2,4.7,.2,id==='canteen'?'#566453':'#34554b');
  for(const x of[-7,7]){box(g,x,2.35,-1.3,.12,4.7,10.6,glass);box(g,x,2.35,6.4,.12,4.7,.6,glass);for(const z of[-6.7,4,6.7])box(g,x,2.4,z,.15,4.8,.15,dark);}
  box(g,0,4.85,-5.7,14.7,.25,2.3,stone);box(g,0,4.67,-4.6,14,.055,.08,'#ffe2a8');
  solid(g,new THREE.PlaneGeometry(7,.65),labelTexture(id==='canteen'?'COMEDOR / CAFÉ':'SALA DE EQUIPO',id==='canteen'?'#566453':'#34554b','#f4e7cb'),0,3.95,-6.53);
  plant(g,-6,-5.4,1.2);plant(g,6,5.4,1.2);
  const sign=id==='canteen'?-1:1;box(room,sign*20.5,-.13,5,4.2,.26,2.3,stone);box(room,sign*20.5,.02,5,4.2,.04,2.1,'#c1a07a');
  if(id==='assembly'){
   box(g,0,1.12,0,8.3,.18,2.8,wood);for(const x of[-3,3])box(g,x,.55,0,.4,1.1,2,dark);
   ASSEMBLY_SEATS.forEach(s=>chair(g,s.x-r.x,s.z,s.facing??0));
   for(const x of[-3,-1,1,3]){box(g,x,1.25,0,.65,.06,.45,dark);cylinder(g,x+.4,1.31,.7,.08,.2,'#f1eada',8);}
   tv(g,0,1.9,-6.48,'assembly',6.8);
  }else{
   CANTEEN_TABLES.forEach(t=>{box(g,t.x-r.x,1.08,t.z,t.width,.15,t.depth,wood);cylinder(g,t.x-r.x,.53,t.z,.16,1.06,dark,12);cylinder(g,t.x-r.x,1.28,t.z,.11,.25,'#e5d9ba',10);});
   CANTEEN_SEATS.forEach(s=>chair(g,s.x-r.x,s.z,s.facing??0,'#677b62'));
   box(g,0,.65,-6.25,6.8,1.3,.7,'#a0aa8d');box(g,0,1.36,-6.25,7,.12,.75,stone);
   const coffee=group(g,-1.5,1.43,-6.25);box(coffee,0,.4,0,.85,.8,.65,dark);box(coffee,0,.29,.35,.55,.35,.08,'#101f1e');cylinder(coffee,0,.15,.45,.12,.22,'#eee8d5',12);interactive(solid(coffee,new THREE.PlaneGeometry(.55,.24),labelTexture('PAUSA','#17372f','#b2ebcf'),0,.63,.34),'timer','canteen');
   for(const x of[.6,1.1,1.6])cylinder(g,x,1.55,-6.08,.13,.25,'#efe6d6',12);tv(g,4.5,2.5,-6.48,'canteen',4.4);
  }
 }
 // A separate glass meeting room within the executive floor.
 const executive=floors[MANAGEMENT.y/6];box(executive,10.7,1.55,2.5,.08,3.1,6.1,glass);box(executive,14,1.55,-.55,6.6,3.1,.08,glass);
 for(const x of[10.7,17.3])box(executive,x,1.6,-.55,.1,3.2,.1,dark);
 solid(executive,new THREE.PlaneGeometry(4.6,.5),labelTexture('SALA DE DIRECCIÓN',dark,'#f4e7cb'),14,4.1,-.42);
 tv(executive,14,2.7,-.4,'management',3.9);
 chair(executive,14,5.2,Math.PI,dark);
 function statusOf(task){
  if(task.status==='done')return task.approvedAt?{label:'APROBADA',color:'#8ed2b0',rank:5}:{label:'PARA REVISAR',color:'#eed290',rank:2};
  return ({running:{label:'EN CURSO',color:'#81dfbd',rank:0},queued:{label:'EN COLA',color:'#add1e8',rank:3},pending:{label:'PENDIENTE',color:'#cbd7d1',rank:4},error:{label:'REQUIERE REVISIÓN',color:'#f3ae8b',rank:1},interrupted:{label:'INTERRUMPIDA',color:'#f3ae8b',rank:1},cancelled:{label:'CANCELADA',color:'#bcc5bf',rank:6}})[task.status]||{label:'SIN ESTADO',color:'#bcc5bf',rank:7};
 }
 const clean=value=>String(value??'').replace(/\s+/g,' ').trim();
 function fit(p,value,width){let text=clean(value);if(p.measureText(text).width<=width)return text;while(text.length&&p.measureText(text+'…').width>width)text=text.slice(0,-1);return text+'…';}
 function lines(p,value,width,count=2){
  const words=clean(value).split(' '),result=[];let line='';
  while(words.length){const word=words.shift(),next=line?line+' '+word:word;
   if(line&&p.measureText(next).width>width){result.push(line);line=word;if(result.length===count-1){line=[line,...words].join(' ');break;}}
   else line=next;
  }
  if(line)result.push(line);return result.slice(0,count).map(text=>fit(p,text,width));
 }
 function drawTask(p,t,index,alpha=1,offset=0){
  const task=t.view.tasks[index];if(!task)return;
  p.save();p.beginPath();p.rect(36,263,952,143);p.clip();p.globalAlpha=alpha;p.translate(0,offset);
  p.fillStyle=task.display.color;p.font='700 24px system-ui';p.fillText(task.display.label,48,290);
  p.fillStyle='#bbcec4';p.textAlign='right';p.font='500 24px system-ui';p.fillText(fit(p,task.owner,400),976,290);p.textAlign='left';
  p.fillStyle='#f2f6ef';p.font='650 37px system-ui';lines(p,task.title,928).forEach((line,i)=>p.fillText(line,48,340+i*45));p.restore();
 }
 function drawScreen(t,now){
  const p=t.canvas.getContext('2d'),view=t.view,tasks=view?.tasks||[],reduced=screenReduced||screenPaused,elapsed=Math.max(0,screenTime-t.cycleStart),hold=8,transition=.32;
  const page=tasks.length?Math.floor(elapsed/hold)%tasks.length:0,phase=elapsed%hold,blend=!reduced&&tasks.length>1&&elapsed>=hold&&phase<transition?phase/transition:1;
  p.clearRect(0,0,1024,512);p.fillStyle='#102824';p.fillRect(0,0,1024,512);p.fillStyle=screenConnected===false?'#eed290':t.accent;p.fillRect(0,0,1024,7);
  p.fillStyle=screenConnected===false?'#eed290':'#a9c5b8';p.font='650 23px system-ui';p.fillText(screenConnected===false?'SIN CONEXIÓN · ÚLTIMOS DATOS':'OFICINA DE EQUIPO  /  TABLERO',48,48);
  p.fillStyle='#f2f6ef';p.font='700 43px system-ui';p.fillText(fit(p,t.title,660),48,106);
  p.textAlign='right';p.font='600 33px ui-monospace, monospace';p.fillText(clockFormat.format(now),976,56);p.font='500 20px system-ui';p.fillStyle='#a9c5b8';p.fillText('BOGOTÁ · UTC−5',976,88);p.textAlign='left';
  const metrics=view?[[view.running,'EN CURSO','#81dfbd'],[view.review,'PARA REVISAR','#eed290'],[tasks.length,'TAREAS REGISTRADAS','#f2f6ef']]:[['—','EN CURSO','#81dfbd'],['—','PARA REVISAR','#eed290'],['—','SIN DATOS AÚN','#f2f6ef']];
  metrics.forEach(([value,title,color],i)=>{const x=48+i*326;p.fillStyle=color;p.font='700 70px system-ui';p.fillText(String(value),x,199);p.fillStyle='#b3cfc1';p.font='600 21px system-ui';p.fillText(title,x,232);});
  p.fillStyle='#18392f';p.fillRect(28,255,968,153);
  if(tasks.length){
   if(blend<1){const ease=blend*blend*(3-2*blend);drawTask(p,t,(page+tasks.length-1)%tasks.length,1-ease,-18*ease);drawTask(p,t,page,ease,18*(1-ease));}
   else drawTask(p,t,page);
  }else{
   p.fillStyle='#eff5eb';p.font='650 35px system-ui';p.fillText(view?'Este tablero todavía no tiene tareas.':screenConnected===false?'Sin conexión con la oficina.':'Esperando el estado de la oficina…',48,318);
   p.fillStyle='#b3cfc1';p.font='25px system-ui';p.fillText(view?'Abre la pantalla para asignar o revisar trabajo.':'El reloj está activo. Las tareas llegarán al sincronizar.',48,366);
  }
  p.fillStyle='#b3cfc1';p.font='500 20px system-ui';
  const received=t.receivedAt?receivedFormat.format(t.receivedAt):'—';p.fillText(`Estado recibido ${received}  ·  ${tasks.length?`${page+1} / ${tasks.length}`:'0 tareas'}`,48,439);
  p.textAlign='right';p.fillStyle='#d9eedf';p.font='700 21px system-ui';p.fillText('CLIC PARA ABRIR  ↗',976,439);p.textAlign='left';
  // This strip rotates real task headlines; it is not simulated task progress.
  p.fillStyle='#0b201c';p.fillRect(0,456,1024,56);p.save();p.beginPath();p.rect(48,460,928,48);p.clip();p.font='500 25px system-ui';p.fillStyle='#c3dbcd';
  if(t.tickerText){
   const travel=!reduced&&t.tickerWidth>928?(elapsed*34)%(t.tickerWidth+90):0;
   if(reduced)p.fillText(fit(p,t.tickerText,928),48,492);
   else{p.fillText(t.tickerText,48-travel,492);if(travel>0)p.fillText(t.tickerText,48-travel+t.tickerWidth+90,492);}
  }else p.fillText(view?'Sin tareas asignadas en este espacio.':'Conecta la oficina para ver sus tareas.',48,492);
  p.restore();t.texture.needsUpdate=true;
 }
 function updateTVs(state){
  if(!Array.isArray(state?.tasks))return;
  const agents=Array.isArray(state?.agents)?state.agents:[],source=Array.isArray(state?.tasks)?state.tasks:[],byAgent=new Map(agents.map(a=>[a.id,a]));
  const receivedAt=new Date();
  for(const t of televisions){
   const all=['management','assembly','canteen'].includes(t.context),tasks=source.filter(task=>all||byAgent.get(task.agent)?.department===t.context).map(task=>({id:task.id,title:clean(task.title)||'Tarea sin título',status:task.status,approvedAt:task.approvedAt,owner:clean(byAgent.get(task.agent)?.person)||'Sin responsable',updatedAt:Date.parse(task.updatedAt||task.createdAt)||0,display:statusOf(task)})).sort((a,b)=>a.display.rank-b.display.rank||b.updatedAt-a.updatedAt);
   const signature=JSON.stringify(tasks);
   if(signature!==t.signature){t.cycleStart=screenTime;t.signature=signature;}
   t.view={tasks,running:tasks.filter(task=>task.status==='running').length,review:tasks.filter(task=>task.status==='done'&&!task.approvedAt).length};
   t.receivedAt=receivedAt;t.tickerText=tasks.slice(0,8).map(task=>`${task.display.label} · ${task.owner}: ${task.title}`).join('    /    ');
   const p=t.canvas.getContext('2d');p.font='500 25px system-ui';t.tickerWidth=p.measureText(t.tickerText).width;
  }
  screenDirty=true;updateScreens(0,screenTime,{reducedMotion:screenReduced,paused:screenPaused});
 }
 function setScreensConnected(connected){
  const next=Boolean(connected);if(screenConnected===next)return;
  screenConnected=next;screenDirty=true;updateScreens(0,screenTime,{reducedMotion:screenReduced,paused:screenPaused});
 }
 function updateScreens(dt,_time,{reducedMotion=motionPreference?.matches??false,paused=false}={}){
  if(screenReduced!==Boolean(reducedMotion)||screenPaused!==Boolean(paused))screenDirty=true;
  screenReduced=Boolean(reducedMotion);screenPaused=Boolean(paused);
  if(!screenReduced&&!screenPaused)screenTime+=Math.max(0,Math.min(Number(dt)||0,.25));
  const now=new Date(),second=Math.floor(now.getTime()/1000),animate=!screenReduced&&!screenPaused;
  // Limit texture uploads; still refresh the real clock when motion is paused.
  if(!screenDirty&&second===lastClockSecond&&(!animate||screenTime-lastScreenPaint<1/12))return;
  for(const t of televisions){let visible=true;for(let node=t.root;node;node=node.parent)if(!node.visible){visible=false;break;}if(visible)drawScreen(t,now);}
  lastClockSecond=second;lastScreenPaint=screenTime;screenDirty=false;
 }
 updateScreens(0,0);
 return{gadgetMeshes,televisions,extraRooms,updateTVs,updateScreens,setScreensConnected};
}
