export const STAGES=[
  {id:'pending',name:'Pendientes',short:'Pendientes',hint:'Lo que quieres que hagan.'},
  {id:'progress',name:'En curso',short:'En curso',hint:'El agente está trabajando.'},
  {id:'review',name:'Para revisar',short:'Revisar',hint:'La entrega está dentro de la tarjeta.'},
  {id:'complete',name:'Terminado',short:'Listo',hint:'Entregas que ya aprobaste.'}
];
export function taskStage(task){
  if(task.status==='done')return task.approvedAt?'complete':'review';
  if(['queued','running'].includes(task.status))return 'progress';
  return 'pending';
}
export const PRIORITIES={high:'Alta',normal:'Normal',low:'Baja'};
