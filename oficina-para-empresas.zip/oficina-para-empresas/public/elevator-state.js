// One source of coordinates for navigation, the rendered shafts and transport.
// Existing office reference: sandstone / honey wood / charcoal / blue glass.
export const ELEVATOR_FLOORS=Object.freeze([0,6,12,18,24]);
export const ELEVATOR_SIZE=Object.freeze({width:1.5,depth:1.5,height:2.8,landingZ:6.95});
export const ELEVATORS=Object.freeze([
  Object.freeze({id:'lift-west',name:'A',x:-.85,z:5.6,initialY:0}),
  Object.freeze({id:'lift-east',name:'B',x:.85,z:5.6,initialY:6})
]);
const smooth=t=>t*t*(3-2*t),mix=(a,b,t)=>a+(b-a)*t;
const EPS=1e-8;
const floor=y=>{if(!ELEVATOR_FLOORS.includes(y))throw new RangeError('Piso de ascensor no disponible.');return y;};
const duration={openingPickup:.24,boarding:.42,closingPickup:.24,openingDropoff:.24,alighting:.42,closingDropoff:.24};

/** Discrete, renderer-independent transport. Capacity is one figure per cabin.
 * requestRide({riderId,fromY,toY,elevatorId?}) is idempotent while that ride exists.
 * update(seconds) advances both cars; getRide/riderPosition return world positions.
 * Queued rides can be cancelled. Once boarding begins, finish safely before rerouting.
 * Reduced motion completes state transitions without any spatial interpolation.
 */
export class ElevatorController {
  constructor({reducedMotion=false}={}){
    this.reducedMotion=Boolean(reducedMotion);this.rides=new Map();this.events=[];this.serial=0;
    this.cars=ELEVATORS.map(spec=>({...spec,y:spec.initialY,door:0,phase:'idle',elapsed:0,duration:0,fromY:spec.initialY,targetY:spec.initialY,queue:[],active:null}));
  }
  requestRide({riderId,fromY,toY,elevatorId}={}){
    if(typeof riderId!=='string'||!riderId)throw new TypeError('A stable riderId is required.');
    floor(fromY);floor(toY);
    const old=this.rides.get(riderId);
    if(old&&!['arrived','cancelled'].includes(old.status)){
      if(old.fromY!==fromY||old.toY!==toY||(elevatorId&&old.elevatorId!==elevatorId))throw new Error('Finish or cancel the existing ride before requesting another destination.');
      return this.getRide(riderId);
    }
    const car=elevatorId?this.cars.find(c=>c.id===elevatorId):[...this.cars].sort((a,b)=>this.estimate(a,fromY)-this.estimate(b,fromY))[0];
    if(!car)throw new RangeError('Unknown elevator.');
    const ride={riderId,ticketId:++this.serial,fromY,toY,elevatorId:car.id,status:fromY===toY?'arrived':'queued'};
    this.rides.set(riderId,ride);
    if(fromY!==toY)car.queue.push(ride);
    this.events.push({type:ride.status,riderId,ticketId:ride.ticketId,elevatorId:car.id});
    return this.getRide(riderId);
  }
  estimate(car,fromY){return Math.abs(car.y-fromY)/6+(car.active?3:0)+car.queue.length*4;}
  cancelRide(riderId){
    const ride=this.rides.get(riderId);if(!ride||ride.status!=='queued')return false;
    const car=this.cars.find(c=>c.id===ride.elevatorId);car.queue=car.queue.filter(r=>r!==ride);ride.status='cancelled';
    this.events.push({type:'cancelled',riderId,ticketId:ride.ticketId,elevatorId:car.id});return true;
  }
  setReducedMotion(value){this.reducedMotion=Boolean(value);}
  begin(car,phase,targetY=car.y){
    car.phase=phase;car.elapsed=0;car.fromY=car.y;car.targetY=targetY;
    car.duration=phase==='positioning'||phase==='moving'?.25+Math.abs(targetY-car.y)/6:duration[phase]??0;
    const r=car.active;
    if(r){
      if(phase==='openingPickup'||phase==='positioning')r.status='calling';
      if(phase==='boarding')r.status='boarding';
      if(phase==='closingPickup'||phase==='moving'||phase==='openingDropoff')r.status='riding';
      if(phase==='alighting')r.status='alighting';
      if(phase==='closingDropoff'){r.status='arrived';this.events.push({type:'arrived',riderId:r.riderId,ticketId:r.ticketId,elevatorId:car.id,toY:r.toY});}
    }
  }
  next(car){
    const r=car.active;
    switch(car.phase){
      case'idle':{
        car.active=car.queue.shift()??null;if(!car.active)return false;
        this.begin(car,Math.abs(car.y-car.active.fromY)>EPS?'positioning':'openingPickup',car.active.fromY);break;
      }
      case'positioning':this.begin(car,'openingPickup');break;
      case'openingPickup':this.begin(car,'boarding');break;
      case'boarding':this.begin(car,'closingPickup');break;
      case'closingPickup':this.begin(car,'moving',r.toY);break;
      case'moving':this.begin(car,'openingDropoff');break;
      case'openingDropoff':this.begin(car,'alighting');break;
      case'alighting':this.begin(car,'closingDropoff');break;
      case'closingDropoff':car.active=null;car.phase='idle';car.door=0;break;
    }
    return true;
  }
  sample(car,t){
    const f=smooth(t);
    if(car.phase==='positioning'||car.phase==='moving'){car.y=mix(car.fromY,car.targetY,f);car.door=0;}
    else if(car.phase==='openingPickup'||car.phase==='openingDropoff')car.door=f;
    else if(car.phase==='closingPickup'||car.phase==='closingDropoff')car.door=1-f;
    else if(car.phase==='boarding'||car.phase==='alighting')car.door=1;
  }
  update(dt){
    if(!Number.isFinite(dt)||dt<0)throw new RangeError('dt must be non-negative seconds.');
    for(const car of this.cars){
      let remaining=dt,steps=0;
      while(steps++<4096){
        if(car.phase==='idle'&&!this.next(car))break;
        if(this.reducedMotion){this.sample(car,1);this.next(car);continue;}
        const use=Math.min(remaining,Math.max(0,car.duration-car.elapsed));car.elapsed+=use;remaining-=use;
        this.sample(car,car.duration?Math.min(1,car.elapsed/car.duration):1);
        if(car.elapsed+EPS<car.duration)break;
        this.next(car);if(remaining<EPS)break;
      }
    }
    return this.getState();
  }
  riderPosition(riderId){
    const r=this.rides.get(riderId);if(!r||r.status==='queued'||r.status==='calling'||r.status==='cancelled')return null;
    const c=this.cars.find(c=>c.id===r.elevatorId),{landingZ}=ELEVATOR_SIZE;
    if(r.status==='arrived')return{x:c.x,y:r.toY,z:landingZ};
    const f=this.reducedMotion?1:smooth(Math.min(1,c.elapsed/(c.duration||1)));
    const z=c.phase==='boarding'?mix(landingZ,c.z,f):c.phase==='alighting'?mix(c.z,landingZ,f):c.z;
    return{x:c.x,y:c.y,z};
  }
  getRide(riderId){const r=this.rides.get(riderId);return r?{...r,position:this.riderPosition(riderId)}:null;}
  getState(){return this.cars.map(c=>({id:c.id,name:c.name,x:c.x,z:c.z,y:c.y,door:c.door,phase:c.phase,targetY:c.targetY,riderId:c.active?.status==='arrived'?null:c.active?.riderId??null,queue:c.queue.map(r=>r.riderId)}));}
  drainEvents(){return this.events.splice(0);}
}
