import * as THREE from './vendor/three.module.js';

// Reference lock: keep the existing penthouse geometry. management revised brief
// owns the club: saturated RGB, many visible light sources, moving beams and a
// prominent Party Time control. Refero motion guide owns pause/reduced-motion.
// LED walls are instanced; light changes are continuous, never a strobe.
export function buildDisco(parent,{box,cylinder,solid,group,labelTexture}){
 const g=group(parent,-10,0,0),ink='#070916',metal='#31384e';
 const light=color=>new THREE.MeshBasicMaterial({color,toneMapped:false});
 const glowTexture=(()=>{const n=64,data=new Uint8Array(n*n*4);for(let y=0;y<n;y++)for(let x=0;x<n;x++){const i=(y*n+x)*4,r=Math.hypot((x-n/2)/(n/2),(y-n/2)/(n/2));data[i]=data[i+1]=data[i+2]=255;data[i+3]=Math.round(Math.max(0,1-r)**2*210);}const texture=new THREE.DataTexture(data,n,n,THREE.RGBAFormat);texture.needsUpdate=true;return texture;})();
 const glow=(parent,x,y,z,size,color)=>{const m=new THREE.SpriteMaterial({map:glowTexture,color,transparent:true,opacity:.62,blending:THREE.AdditiveBlending,depthWrite:false,toneMapped:false});const sprite=new THREE.Sprite(m);sprite.position.set(x,y,z);sprite.scale.setScalar(size);parent.add(sprite);return sprite;};
 const colors=[],tiles=[],bars=[],beams=[],pools=[],bulbs=[],pointLights=[],rings=[];
 const neon=(color,phase=0)=>{const m=light(color);colors.push({material:m,phase});return m;};
 box(g,0,.08,.1,16,.08,12,ink);box(g,0,2.65,-6.15,16,5.1,.22,light(ink));
 for(const x of[-7.9,7.9])box(g,x,2.5,-2,.12,4.9,8,light('#0b1020'));
 // A luminous frame separates the club from the warm executive suite.
 for(const x of[-7.8,7.8]){box(g,x,2.65,-5.98,.1,5,.1,neon('#ff29c7',x*.05));box(g,x,.22,.4,.07,.08,11.9,neon('#17ecff',x*.07));}
 for(const y of[.25,5.03])box(g,0,y,-5.95,15.7,.07,.08,neon('#25fbef',y*.2));
 const sign=solid(g,new THREE.PlaneGeometry(8.6,.86),labelTexture('PARTY TIME',ink,'#ffffff',{width:1280,height:128,fontSize:102}),0,4.47,-5.8);
 // The sign remains legible against the RGB wall.
 sign.material=new THREE.MeshBasicMaterial({map:sign.material.map,toneMapped:false});
 solid(g,new THREE.PlaneGeometry(7,.3),labelTexture('AFTER HOURS  /  PISO 05',ink,'#83f9ff',{width:1024,height:64,fontSize:38}),0,3.78,-5.8);
 box(g,0,.14,.7,13.8,.12,8.9,'#070915');
 for(let row=0;row<6;row++)for(let col=0;col<7;col++){
  const material=light('#00ffff');box(g,-5.7+col*1.9,.215,-2.9+row*1.44,1.82,.025,1.36,material);tiles.push({material,col,row});
  // Bright joints make every individual tile read as a light source.
  box(g,-5.7+col*1.9,.231,-2.9+row*1.44,1.7,.008,.025,neon('#b3ffff',col*.1+row*.05));
 }
 for(const x of[-6.95,6.95])box(g,x,.19,.7,.07,.08,8.95,neon('#ff27c4',x*.02));
 for(const z of[-3.77,5.17])box(g,0,.19,z,13.9,.08,.07,neon('#20ffda',z*.07));
 // Two LED matrices with one draw call each, rather than hundreds of lamps.
 const matrices=[];const matrix=new THREE.Matrix4(),color=new THREE.Color();
 for(const side of[-1,1]){
  const leds=new THREE.InstancedMesh(new THREE.BoxGeometry(.19,.19,.05),light('#ffffff'),7*17);let i=0;
  for(let row=0;row<17;row++)for(let col=0;col<7;col++){matrix.makeTranslation(side*5.9+(col-3)*.31,.6+row*.24,-5.91);leds.setMatrixAt(i,matrix);color.setHSL((col*.09+row*.04+side*.15+1)%1,1,.52);leds.setColorAt(i++,color);}
  leds.instanceMatrix.needsUpdate=true;leds.instanceColor.needsUpdate=true;g.add(leds);matrices.push({mesh:leds,side});
 }
 box(g,0,.74,-4.58,6.3,1.4,1.15,'#111626');box(g,0,1.48,-4.58,6.5,.14,1.28,metal);
 for(let i=-14;i<=14;i++)box(g,i*.21,.75,-3.98,.075,1.25,.04,neon('#ff3cba',(i+14)*.025));
 for(const x of[-1.8,1.8]){box(g,x,1.59,-4.6,1.45,.09,.98,'#101322');cylinder(g,x,1.66,-4.6,.43,.035,'#687975',32);cylinder(g,x,1.69,-4.6,.15,.02,neon('#0cffff',x*.1),24);}
 box(g,0,1.61,-4.6,1.1,.14,.83,ink);
 for(let i=0;i<5;i++){box(g,-.38+i*.19,1.7,-4.6,.03,.025,.5,'#9db0a5');box(g,-.38+i*.19,1.73,-4.45-(i%3)*.12,.1,.05,.08,neon('#ffff6b',i*.2));}
 for(let i=0;i<25;i++){const b=box(g,-3.5+i*.29,2.55,-5.7,.19,.3,.035,neon('#aaff00',i*.04));bars.push(b);}
 for(const x of[-6.5,6.5]){
  box(g,x,1.2,-4.85,1.35,2.35,1.05,'#111426');
  for(const y of[.7,1.55]){const speaker=solid(g,new THREE.CylinderGeometry(.4,.4,.08,24),light('#03050a'),x,y,-4.28);speaker.rotation.x=Math.PI/2;const rim=solid(g,new THREE.TorusGeometry(.41,.038,8,32),neon('#00ffeb',x*.07+y*.2),x,y,-4.22);rim.castShadow=false;rings.push(rim);glow(g,x,y,-4.18,1.5,'#23ffde');}
 }
 for(const x of[-7.65,7.65]){box(g,x,.45,1,.7,.7,5.4,'#21243b');box(g,x+Math.sign(x)*.25,.9,1,.18,.7,5.4,'#39345b');box(g,x,.12,1,.75,.04,5.4,neon('#ff3ca1',x*.06));for(let i=-1;i<=1;i++)box(g,x,.85,1+i*1.65,.64,.12,1.5,'#4e4366');}
 cylinder(g,0,4.98,.2,.025,.45,metal,8);
 const mirror=solid(g,new THREE.SphereGeometry(.65,20,12),new THREE.MeshStandardMaterial({color:'#e5eaf9',emissive:'#b5ceef',emissiveIntensity:.24,metalness:.52,roughness:.12,flatShading:true}),0,4.25,.2);
 const seams=solid(g,new THREE.SphereGeometry(.654,20,12),new THREE.MeshBasicMaterial({color:'#808eb2',wireframe:true,transparent:true,opacity:.35}),0,4.25,.2);
 const halo=solid(g,new THREE.TorusGeometry(.92,.025,8,64),neon('#00ffff',.3),0,4.2,.2);halo.rotation.x=Math.PI/2;
 // Three overhead lighting rigs, 12 swivelling heads, visible cones and pools.
 for(const z of[-2.8,.4,3.7]){
  box(g,0,5.02,z,15,.12,.14,metal);box(g,0,4.94,z,14.9,.035,.035,neon('#24ffff',z*.12));
  for(const x of[-5.5,-1.9,1.9,5.5]){
   const i=beams.length,pivot=group(g,x,4.79,z);box(pivot,0,.04,0,.35,.28,.36,'#191c2e');cylinder(pivot,0,-.15,0,.17,.05,neon('#ffffff',i*.083),12);
   const material=new THREE.MeshBasicMaterial({color:'#ff24dd',transparent:true,opacity:.12,depthWrite:false,side:THREE.DoubleSide,blending:THREE.AdditiveBlending,toneMapped:false});
   const beam=solid(pivot,new THREE.ConeGeometry(.7,4.4,20,1,true),material,0,-2.42,0);beam.castShadow=false;beam.receiveShadow=false;
   const bulb=glow(pivot,0,-.17,0,1.3,'#ff2ad5');bulbs.push(bulb);beams.push({pivot,material,x,z});
   const pool=solid(g,new THREE.PlaneGeometry(2.5,2.5),new THREE.MeshBasicMaterial({map:glowTexture,color:'#ff2ed7',transparent:true,opacity:.7,depthWrite:false,blending:THREE.AdditiveBlending,toneMapped:false}),x,.25,z);pool.rotation.x=-Math.PI/2;pool.castShadow=false;pools.push(pool);
  }
 }
 // Narrow fans cross above the floor. Geometry keeps them visible in daylight.
 const lasers=[];for(const side of[-1,1])for(let i=0;i<5;i++){
  const pivot=group(g,side*7,3.2,-4.8),m=new THREE.MeshBasicMaterial({color:'#30ffb4',transparent:true,opacity:.28,depthWrite:false,blending:THREE.AdditiveBlending,toneMapped:false});
  const laser=solid(pivot,new THREE.CylinderGeometry(.009,.018,9,5),m,0,-4.5,0);laser.castShadow=false;lasers.push({pivot,material:m,side,i});
 }
 const dots=new THREE.InstancedMesh(new THREE.CircleGeometry(.055,6),light('#ffffff'),60);
 for(let i=0;i<60;i++){matrix.makeRotationX(-Math.PI/2);matrix.setPosition(Math.sin(i*2.399)*(.7+i%7),.25,Math.cos(i*2.399)*(1+i%4)+.5);dots.setMatrixAt(i,matrix);color.setHSL(i/60,1,.7);dots.setColorAt(i,color);}dots.instanceColor.needsUpdate=true;g.add(dots);
 for(const x of[-5,0,5]){const lamp=new THREE.PointLight('#ff31e0',12,13,2);lamp.position.set(x,3.5,1);g.add(lamp);pointLights.push(lamp);}
 let lastTime=0;
 return{group:g,update(time,{reducedMotion=false,paused=false,enabled=true,partyAll=false}={}){
  if(!paused)lastTime=time;const t=reducedMotion?0:lastTime,hue=t*.055,boost=partyAll?1:.84;
  mirror.rotation.y=seams.rotation.y=t*.45;halo.rotation.z=t*.32;
  tiles.forEach(({material,col,row})=>material.color.setHSL((hue+col*.085+row*.115)%1,1,enabled?(.36+.12*(.5+.5*Math.sin(t*1.9+col*.7-row*.9)))*boost:.1));
  colors.forEach(({material,phase})=>material.color.setHSL(((hue+phase)%1+1)%1,1,enabled?.58:.15));
  matrices.forEach(({mesh,side})=>{let i=0;for(let row=0;row<17;row++)for(let col=0;col<7;col++){color.setHSL((hue+row*.035+col*.065+side*.16+1)%1,1,enabled?.3+.3*(.5+.5*Math.sin(t*1.7+row*.4+col*.8)):.08);mesh.setColorAt(i++,color);}mesh.instanceColor.needsUpdate=true;});
  bars.forEach((b,i)=>{const h=enabled?.28+(Math.sin(t*2.3+i*.65)+1)*.4:.12;b.scale.y=h;b.position.y=2.25+h/2;});
  beams.forEach(({pivot,material,x,z},i)=>{
   const h=(hue+i/12)%1;material.color.setHSL(h,1,.6);material.opacity=enabled?.1*boost:0;
   pivot.rotation.z=Math.sin(t*.55+i*1.7)*.3;pivot.rotation.x=Math.cos(t*.48+i*1.3)*.24;
   bulbs[i].material.color.copy(material.color);bulbs[i].visible=enabled;
   pools[i].visible=enabled;pools[i].material.color.copy(material.color);pools[i].position.x=x+Math.sin(pivot.rotation.z)*4.4;pools[i].position.z=z-Math.sin(pivot.rotation.x)*4.4;
  });
  lasers.forEach(({pivot,material,side,i})=>{pivot.visible=enabled;pivot.rotation.z=side*(.55+i*.14+Math.sin(t*.38+i*.2)*.12);pivot.rotation.x=-.7+Math.sin(t*.45+i)*.15;material.color.setHSL((hue+i*.05+(side>0?.5:0))%1,1,.55);});
  pointLights.forEach((lamp,i)=>{lamp.color.setHSL((hue+i/3)%1,1,.55);lamp.intensity=enabled?14*boost:0;});
  rings.forEach((ring,i)=>ring.scale.setScalar(1+(enabled?Math.sin(t*1.9+i)*.035:0)));
  dots.visible=enabled;dots.rotation.y=t*.13;
 }};
}

// Original, locally synthesized groove. Starts only after an explicit click.
export class DiscoAudio{
 constructor(){this.enabled=false;this.step=0;this.timer=null;}
 async start(){
  const Audio=globalThis.AudioContext||globalThis.webkitAudioContext;if(!Audio)throw new Error('Este navegador no admite audio.');
  if(!this.context){this.context=new Audio();this.master=this.context.createGain();this.master.gain.value=.12;this.master.connect(this.context.destination);}
  await this.context.resume();this.enabled=true;this.next=this.context.currentTime+.05;this.step=0;
  clearInterval(this.timer);this.timer=setInterval(()=>this.schedule(),80);this.schedule();
 }
 note(frequency,start,duration,type,volume,endFrequency){
  const c=this.context,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.setValueAtTime(frequency,start);if(endFrequency)o.frequency.exponentialRampToValueAtTime(endFrequency,start+duration);
  g.gain.setValueAtTime(.001,start);g.gain.exponentialRampToValueAtTime(volume,start+.008);g.gain.exponentialRampToValueAtTime(.001,start+duration);o.connect(g);g.connect(this.master);o.start(start);o.stop(start+duration+.02);o.onended=()=>{o.disconnect();g.disconnect();};
 }
 schedule(){if(!this.enabled||this.context.state!=='running')return;const c=this.context;if(this.next<c.currentTime)this.next=c.currentTime+.03;
  while(this.next<c.currentTime+.18){const s=this.step%16,t=this.next;if(s%4===0)this.note(135,t,.18,'sine',.8,42);if(s%2===0)this.note(3500,t,.025,'square',.035,2200);if(s%4===2)this.note(220,t,.07,'triangle',.25,90);
   if([0,3,6,8,11,14].includes(s))this.note([110,130.81,98,146.83][Math.floor(this.step/16)%4],t,.19,'triangle',.3);
   this.next+=60/112/4;this.step++;
  }
 }
 async pause(){clearInterval(this.timer);this.timer=null;if(this.context?.state==='running')await this.context.suspend();}
 async stop(){this.enabled=false;await this.pause();}
}
